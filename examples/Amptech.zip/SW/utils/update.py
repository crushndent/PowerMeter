#!/usr/bin/python

import os
import sys
import json
import random
import time
import datetime
import urllib2
from urllib import urlencode
import httplib

# Our modules
import config

class Updater:
    def __init__(self, host='127.0.0.1', port=8000):
        print "Opening connection to %s:%d" % (host, port)
        self._c = httplib.HTTPConnection(host=host, port=port, timeout=10)

    def __del__(self):
        self._c.close()

    def rqstCmd(self):
        try:
            self._c.request('/power/command/update')
            r = self._c.getresponse()
            return r.read()
        except httplib.HTTPException, e:
            print e.read()

    def sendStats(self,objs):
        try:
            l = len(objs)
            for i, obj in enumerate(objs):
                print "%d/%d" % (i+1,l)
                params = urlencode({'u': json.dumps(obj)})
                self._c.request('POST', '/power/command/update/', params)
                r = self._c.getresponse()
                ret_val = r.read()        

                try:
                    j = json.loads(ret_val)
                except Exception, e:
                    print "Exception: ret_val logged to out.html" 
                    with open("out.html","w") as h:
                        h.write(ret_val)
                    raise e

                u = sum(map(len, [j.get('unknown_installations'),
                                  j.get('unknown_installations'),
                                  j.get('unknown_combiners'),
                                  j.get('unknown_strings')]))

                if 0 < u:
                    print "Unknowns: %d" % u
                    self.sendConfig(config.get_config())
        except httplib.HTTPException, e:
            print e.read()

    def sendConfig(self,obj):
        try:
            params = urlencode({'c': json.dumps(obj)})
            self._c.request('POST', '/power/command/config/', params)
            r = self._c.getresponse()
            print r.read()
        except urllib2.HTTPError, e:
            print e.read()

def g_data(cfg,t=None):
    r"""
    If `t` is a number, add `t * 10` seconds to utcnow() for 
    recordTime's.
    """

    dat = {
        'installation': cfg.get('installation').get('uuid'),
        'coordinator': cfg.get('installation').get('coordinator').get('uuid'),
        'inverters': [],
        'combiners': [],
        'strings': []
    }

    def gen_t():
        fmt = "%Y-%m-%d %H:%M:%S.%f"
        if None == t:
            return datetime.datetime.utcnow().strftime(fmt)
        else:
            return t.strftime(fmt)

    for i in cfg.get('installation').get('coordinator').get('inverters'):
        dat['inverters'].append ({'uuid' : i.get('uuid')})        

    for c in cfg.get('installation').get('coordinator').get('combiners'):

        t_current = 0 # Total current from strings.

        for s in c.get('strings'):
            current = 6.0 + random.uniform(-1,1)
            t_current += current

            dat['strings'].append({
                'uuid': s.get('uuid'),
                'current': current,
                'recordTime': gen_t()
            })

        dat['combiners'].append({
            'uuid': c.get('uuid'),
            'voltage': 5.0 + random.uniform(-1,1),
            'current': t_current,
            'temperature': 20.0 + random.uniform(-1,1),
            'recordTime': gen_t()
        })

    return dat


if __name__ == '__main__':
    if not os.path.exists(config.CONFIG_PATH):
        config.create()
    j = config.get_config()

    port = 8000

    if len(sys.argv) > 2:
        port = int(sys.argv[2])

    u = Updater(port=port)

    if len(sys.argv) <= 1:
        u.sendStats([g_data(j)])
    else:
        n = datetime.datetime.utcnow()
        d = datetime.timedelta(seconds=10)

        objs = []
        count = int(sys.argv[1])


        if count == 0: # run forever
            sent = 0
            while True:
                print "Sending %d" % sent
                u.sendStats([g_data(j)])
                time.sleep(3)
        else:
            for i in range(0,count):
                print "Sample %d" % i
                objs.append(g_data(j,n + (d * i)))
            u.sendStats(objs)
