#!/usr/bin/python

import json
import random
import uuid

CONFIG_PATH = 'config.txt'

def g_config():
    random.seed()

    def g_strings(cmb):
        c = 12 #random.randint(1,5)

        for i in range(0,c):
            yield {
                'uuid': unicode(uuid.uuid4()),
                'name': 'string#%d.%d' % (cmb,i)
            }

    def g_combiners():
        c = 3 # random.randint(1,2)

        for i in range(0,c):
            yield {
                'name': 'combiner#%d' % i,
                'mac': '00:13:a2:00:40:4a:a1:b8!', # randomize this
                'strings': list(g_strings(i)),
                'node_cmd': '1',
                'uuid': unicode(uuid.uuid4())
            }

    def g_inverters():
        c = 5 # random.randint(1,1)
        
        for i in range(0,c):
            yield {
                'uuid': unicode(uuid.uuid4()),
                'name': 'inverter#%d' % i
            }

    return {
        'installation' : {
            'coordinator' : {
                'inverters' : list(g_inverters()),
                'combiners' : list(g_combiners()),
                'uuid' : unicode(uuid.uuid4()),
            },
            'uuid' : unicode(uuid.uuid4()),
            'server_ip' : '0.0.0.0',
            'name': unicode("An Installation")
        }
    }

def create():
    j = json.dumps(g_config(), indent=2, sort_keys=True)
    h = open(CONFIG_PATH, 'w')
    h.write(j)
    h.close()

def get_config():
    h = open(CONFIG_PATH,'r')
    j = json.loads(h.read())
    h.close()
    return j

if __name__ == '__main__':
    create()
    print "Wrote config file to %s" % CONFIG_PATH
