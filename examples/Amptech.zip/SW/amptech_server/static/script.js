function drawGraph(container,url) {
    function gotData(d) {
        $.plot(container, d,
            {
                series: {
                    lines: { show: true },
                    points: { show: false }
                },
                grid: {
                    backgroundColor: { colors: ["#fff", "#eee"] }
                },
                xaxis: {
                    tickFormatter: function (n) {
                        var d = new Date(n * 1000),
                            year = d.getFullYear(),
                            month = d.getMonth() + 1,
                            day = d.getDate(),
                            hours = d.getHours(),
                            minutes = Right("00"+d.getMinutes(),2),
                            seconds = Right("00"+d.getSeconds(),2);
                        return month + "/" + day + " " + hours + ":" + minutes;
                    },
                    ticks: 5
                }
            });
    }

    $.ajax({
        url: url,
        method: "GET",
        dataType: "json",
        success: gotData
    })
}

/* function utc2local
 *
 *  utc - integer - milliseconds since Jan 1 1970
 *
 *  return: integer - milliseconds since Jan 1 1970 in local time
 */
function utc2local(utc) {
    var d = new Date(),
        ofst = d.getTimezoneOffset() * (60 * 1000);

    return utc - ofst;
}

function local2utc(local) {
    var d = new Date(),
        ofst = d.getTimezoneOffset() * (60 * 1000);

    return local + ofst;
}

/* function Right
 *
 *  str - string - string to manipulate
 *  n - integer - number of characters to take from the string on the right side.
 *
 *  return: string - string sliced from the right side.
 */
function Right(str, n){
if (n <= 0)
    return "";
else if (n > String(str).length)
    return str;
else {
       var iLen = String(str).length;
       return String(str).substring(iLen, iLen - n);
    }
}

var refresh_time=15000;
var max_range = {}; /* Holds maximum ranges for the specific container. */

function drawBarGraph(container,url,element) {

    function update_max_range(data) {
        /* Pull out the piece we need from an element. */
        function extract(d) {
            if (undefined === d.data[0]) {
                return 0;
            } else {
                return d.data[0][0];
            }
        }

        var values = data.graph_d.map(extract),
            this_max = Math.max.apply(this, values); /* Pick the maximum */

        /* If we don't have a value or the new value is larger, update */
        if (undefined === max_range[container] || max_range[container] < this_max) {
            max_range[container] = this_max;
        }
    }

    function gotData(d) {
        var data=d;

        update_max_range(data);

        if(element!=undefined){
            d=d[element];
        }
        var options = {
            series: {
                bars: { show: true}
                },
            bars: {
                    align: "center",
                    horizontal: true
                },
            grid: {
                backgroundColor: { colors: ["#fff", "#eee"] }
                },
            legend: {show: false },
            xaxis: { min: 0, max: max_range[container] },
            yaxis: { 
                ticks: d.length,
                minTickSize: 1,
                tickFormatter: function(n) {
                    if ( (n < 0) || (n > (d.length)-1) ) {
                        return "";
                    }else {
                        return d[n].label;
        }   }   }   };

        UpdateTables(data);
        d=d.reverse()
        $.plot($(container), d, options);
    }

    $.ajax({
        url: url,
        method: "GET",
        dataType: "json",
        success: gotData
    })
}

function getAlerts(level, uuid) {
    function combineData(d) {
        q=d;
    }
    $.ajax({
        url: "/power/alerts/"+level+"/"+uuid+"/",
        method: "GET",
        dataType: "json",
        success: combineData
    });
}

