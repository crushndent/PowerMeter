#!/usr/bin/python

import sys,os
import smtplib  

import datetime
import time

sys.path.append('../')
os.environ['DJANGO_SETTINGS_MODULE'] ='amptech_server.settings'

from django.core.management import setup_environ
from django.db.models import Avg
from amptech_server import settings
from amptech_server.power.models import *

setup_environ(settings)

#Time in seconds between alert checks
UPDATE_RATE=30
FIXED_VOLTAGE=50.0
check = True

def check_alerts():
    def send_mail(cont, alerthist):
        fromaddr = 'energyamptech@yahoo.com'  
        toaddrs  = ['tom.cruttenden@dornerworks.com'  ]
        note = 'There was a terrible error that occured and I wanted you to know!'  
        subject="Site error"
        # Credentials (if needed)  
        username = 'energyamptech'  
        password = 'k<?>?>":LHgjhfgjh54394308967:LK'  

        #Format and Send Message
        msg = "From: %s\nTo: %s\nSubject: %s\n\n%s" %(fromaddr,toaddrs,subject,note)
        server = smtplib.SMTP("smtp.mail.yahoo.com")
        server.login(username,password)
        #server.sendmail(fromaddr,toaddrs,msg)
        server.close()
    
    def send_alert(alert, inv, comb, coord, str):
        #Check for existing alert with uuid and alert definition index as active alarm (no stop time).
        #Does not exist, 
            #then add it (along with chkField), signal the contacts in the necessary ways.
        #If it does exist, then update the chkField
        try:
            a = AlertHistory.objects.filter(definition=alert, installation=site, endTime__isnull=True)
            if inv<>0:
                a=a.filter(inverter=inv)
            if comb<>0:
                a=a.filter(combiner=comb)
            if coord<>0:
                a=a.filter(coordinator=coord)
            if str<>0:
                a=a.filter(string=str)
            a=a.get()
            a.checkField = check
        except AlertHistory.DoesNotExist:
            a=AlertHistory(definition=alert, installation=site, \
                startTime=datetime.datetime.utcnow(), checkField=check)
            if inv <>0:
                a.inverter=inv
            if comb <>0:
                a.combiner=comb
            if coord <>0:
                a.coordinator=coord
            if str<>0:
                a.string=str
            
            print "set alert %s"%(alert.name)
            #Signal to the contact.
            contacts = alert.contact.all()
            for cont in contacts:
                #Send EMAIL, PHONE, SMS message to the contact person
                #TODO
                send_mail(cont, a)
        a.save()

    def duration(alert):
        d=alert.duration
        intvl=datetime.timedelta(hours=d.hour, minutes=d.minute,seconds=d.second)
        return (datetime.datetime.utcnow()-intvl)

    def power_alert(alert,site):
        combiners=Combiner.objects.filter(inverter__installation=site)
        history=CombinerHistory.objects \
            .filter(combiner__inverter__installation=site)
        history.filter(recordTime__gte=duration(alert))

        for cmbner in combiners:
            #This isn't correct - must be V*I(from strings [summed])
            totalHist = history
            totalHist=totalHist.exclude(combiner=cmbner)
            avgPower=totalHist.aggregate(Avg('voltage'))
            
            cmbnrHist=history
            cmbnrHist=cmbnrHist.filter(combiner=cmbner)
            #This isn't correct either.
            power=cmbnrHist.aggregate(Avg('voltage'))
            print avgPower['voltage__avg'], power, cmbner.name
            if avgPower['voltage__avg']*alert.low > power['voltage__avg'] or \
                avgPower['voltage__avg']*alert.high < power['voltage__avg']:
                #There was a problem
                send_alert(alert, cmbnr.inverter, cmbner, cmbnr.coordinator,0)

        #Now check the strings
        strings=String.objects.filter(combiner__inverter__installation=site)
        history=StringHistory.objects \
            .filter(combiner__inverter__installation=site)
        history.filter(recordTime__gte=duration(alert))

        for strg in strings:
            #This isn't correct - must be V*I(from strings [summed])
            totalHist = history
            totalHist=totalHist.exclude(combiner=cmbner)
            avgPower=totalHist.aggregate(Avg('voltage'))
            
            strgHist=history
            strgHist=strgHist.filter(string=strg)
            #This isn't correct either.
            power=strgrHist.aggregate(Avg('voltage'))
            print avgPower['voltage__avg'], power, strg.name
            if avgPower['voltage__avg']*alert.low > power['voltage__avg'] or \
                avgPower['voltage__avg']*alert.high < power['voltage__avg']:
                #There was a problem
                send_alert(alert, strg.combiner.inverter, strg.cmbner, strg.combiner.coordinator,strg)
    def vltg_alert(alert,site):
        combiners=Combiner.objects.filter(inverter__installation=site)
        history=CombinerHistory.objects \
            .filter(combiner__inverter__installation=site)
        history.filter(recordTime__gte=duration(alert))

        for cmbner in combiners:
            totalHist = history
            totalHist=totalHist.exclude(combiner=cmbner)
            avgPower=totalHist.aggregate(Avg('voltage'))
            
            cmbnrHist=history
            cmbnrHist=cmbnrHist.filter(combiner=cmbner)
            power=cmbnrHist.aggregate(Avg('voltage'))
            print avgPower['voltage__avg'], power, cmbner.name
            if avgPower['voltage__avg']*alert.low > power['voltage__avg'] or \
                avgPower['voltage__avg']*alert.high < power['voltage__avg']:
                #There was a problem
                send_alert(alert,cmbnr.inverter,cmbner,cmbnr.coordinator,0)

    def temp_alert(alert,site):
        combiners=Combiner.objects.filter(inverter__installation=site)
        history=CombinerHistory.objects \
            .filter(combiner__inverter__installation=site)
        history.filter(recordTime__gte=duration(alert))

        for cmbner in combiners:
            totalHist = history
            totalHist=totalHist.exclude(combiner=cmbner)
            avgTemp=totalHist.aggregate(Avg('temperature'))
            
            cmbnrHist=history
            cmbnrHist=cmbnrHist.filter(combiner=cmbner)
            temp=cmbnrHist.aggregate(Avg('temperature'))
            print avgTemp['temperature__avg'], temp, cmbner.name
            if avgTemp['temperature__avg']*alert.low > temp['temperature__avg'] \
                or \
                avgTemp['temperature__avg']*alert.high < temp['temperature__avg']:
                #There was a problem
                send_alert(alert, cmbnr.inverter,cmbner,cmbnr.coordinator,0)

    def coord_timeout(alert,site):
        #Get Installation, then all the coordinators in the install, see if there are any that
        # have not reported in the timeout period.
        last_report = duration(alert)
        timeouts = Coordinator.objects.filter(reportTime__lt=last_report, installation=site)
        for coord in timeouts:
            #There is a timeout error, report this.
            send_alert(alert, 0,0,coord,0)

    def node_timeout(alert,site):
        #Get Installation, then all the coordinators in the install, make sure all 
        # coordinators are still reporting, then see if there are any nodes that
        # have not reported in the timeout period. If they have not reported, check to see if the last 
        # voltage is less than a fixed amount. If it's not, then there was a timeout.
        last_report = duration(alert)
        reporters = Combiner.objects.filter(coordinator__reportTime__gte=last_report, \
            coordinator__installation=site)
        for cmbnr in reporters:
            history = CombinerHistory.objects.filter(combiner=cmbnr).order_by('-recordTime')[:1].get()
            if ((history.voltage >= FIXED_VOLTAGE) &
                (history.recordTime < last_report)):
                #There is a timeout error, report this.
                send_alert(alert, cmbnr.inverter,cmbnr,cmbnr.coordinator,0)
        reporters = Inverter.objects.filter(coordinator__reportTime__gte=last_report, \
            coordinator__installation=site)
#        for inv in reporters:
#            history = InverterHistory.objects.filter(inverter=inv).order_by('-recordTime')[:1].get()
#            if (history.recordTime < last_report):
                #There is a timeout error, report this.
#                send_alert(alert, inv,0,inv.coordinator,0)

    installations=Installation.objects.all()
    for site in installations:
        alerts=AlertDef.objects.all()
        for alert in alerts:
            if alert.parameter=='P':
                power_alert(alert,site)
            if alert.parameter=='V':
                vltg_alert(alert,site)
            if alert.parameter=='T':
                temp_alert(alert,site)
            if alert.parameter=="C":
                coord_timeout(alert,site)
            if alert.parameter=="N":
                node_timeout(alert,site)
        #Now that all alerts are checked for the site, check if some alerts are no-longer alerts
        ah = AlertHistory.objects.exclude(checkField=check)
        ah=ah.filter(installation=site, endTime__isnull=True)
        for done in ah:
            print "clear alert %s"%(done.definition.name)
            done.endTime = datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
            done.save()

if __name__ == '__main__':
    check = True
    while True:
        try:
            check_alerts()
            print "%s OK" %(datetime.datetime.now())
            time.sleep(UPDATE_RATE)
        except:
            pass
        if (check == False):
            check = True
        else:
            check = False
    
    
