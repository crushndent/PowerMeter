#!/bin/sh

for i in `ls /var/run/django-power.pid-*`; do
    PID=`cat $i`
    echo Stopping $PID
    kill $PID
    rm $i
done
