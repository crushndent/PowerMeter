from amptech_server.power.models import *
from django.contrib import admin

admin.site.register(Installation)
admin.site.register(Inverter)
admin.site.register(Combiner)
admin.site.register(String)
admin.site.register(Contact)
admin.site.register(AlertDef)
