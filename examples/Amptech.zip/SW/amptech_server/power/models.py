from django.db import models

# Installation details (usually a specific customer)
class Installation(models.Model):
    uuid        = models.CharField(max_length=36, unique=True)
    name        = models.CharField(max_length=128)
    description = models.CharField(max_length=512,null=True, blank=True)
    historytime = models.IntegerField(default=28800) # 8 hours

    def __unicode__(self):
        return self.name

# The coordinator is the Digi ConnectPortX8
# keep track so that we know which devices are linked to the X8
# and we can determine if it can't connect instead of flagging all the
# individual nodes.
class Coordinator(models.Model):
    uuid         = models.CharField(max_length=36, unique=True)
    installation = models.ForeignKey(Installation)
    reportTime   = models.DateTimeField()
    def __unicode__(self):
        return self.uuid

# These are the base devices in an installation.
class Inverter(models.Model):
    uuid         = models.CharField(max_length=36, unique=True)
    name         = models.CharField(max_length=128)
    location     = models.CharField(max_length=512,null=True, blank=True)
    installation = models.ForeignKey(Installation)
    coordinator  = models.ForeignKey(Coordinator)

    def __unicode__(self):
        return self.name

class Combiner(models.Model):
    uuid         = models.CharField(max_length=36, unique=True)
    name         = models.CharField(max_length=128)
    location     = models.CharField(max_length=512,null=True, blank=True)
    inverter     = models.ForeignKey(Inverter, null=True)
    installation = models.ForeignKey(Installation)
    coordinator  = models.ForeignKey(Coordinator)
    
    def __unicode__(self):
        return self.name

class String(models.Model):
    uuid       = models.CharField(max_length=36, unique=True)
    name       = models.CharField(max_length=128)
    location   = models.CharField(max_length=512,null=True, blank=True)
    combiner   = models.ForeignKey(Combiner)

    def __unicode__(self):
        return self.name

# Models to hold historical data.
# TODO: Pull this back in when the inverter actually has
# something to save.
# class InverterHistory(models.Model):
#     inverter   = models.ForeignKey(Inverter, db_index=True)
#     recordTime = models.DateTimeField(db_index=True) 

class CombinerHistory(models.Model):
    combiner    = models.ForeignKey(Combiner, db_index=True)
    voltage     = models.FloatField()
    current     = models.FloatField()
    temperature = models.FloatField()
    humidity    = models.FloatField(null=True)
    recordTime  = models.DateTimeField(db_index=True)  

    def __unicode__(self):
        return self.recordTime

class CombinerStats(models.Model):
    string = models.ForeignKey(String, db_index=True)
    voltage     = models.FloatField()
    current     = models.FloatField()
    temperature = models.FloatField()
    humidity    = models.FloatField(null=True)
    recordTime = models.DateTimeField(db_index=True)
    type = models.IntegerField()

class StringHistory(models.Model):
    string     = models.ForeignKey(String, db_index=True)
    current    = models.FloatField()
    recordTime = models.DateTimeField(db_index=True) 

    def __unicode__(self):
        return self.recordTime

class StringStats(models.Model):
    string = models.ForeignKey(String, db_index=True)
    current = models.FloatField()
    recordTime = models.DateTimeField(db_index=True)
    type = models.IntegerField()

class Contact(models.Model):
    name         = models.CharField(max_length=128)
    email        = models.EmailField(null=True)
    sms          = models.CharField(max_length=128,null=True, blank=True)
    note         = models.CharField(max_length=256,null=True, blank=True)
    installation = models.ForeignKey(Installation)

    def __unicode__(self):
        return self.name

ALERT_TYPES = (
    ('P', 'Power Performance'), #Power comparison of strings.
    ('V', 'Voltage'), #voltage comparison of combiners.
#    ('E', 'Efficiency'), #Efficiency comparison of inverters - not implemented right now.
    ('T', 'Temperature'),
#    ('H', 'Humidity'),
    ('N', 'Node communication loss'), #Either combiner or inverter node
    ('C', 'Coordinator communication loss') #Coordinator only node
)

class AlertDef(models.Model):
    name         = models.CharField(max_length=128)
    high         = models.FloatField(null=True, blank=True)
    low          = models.FloatField(null=True, blank=True)
    duration     = models.TimeField()
    parameter    = models.CharField(max_length=1, choices=ALERT_TYPES)
    installation = models.ForeignKey(Installation)
    contact      = models.ManyToManyField(Contact)
   
    def __unicode__(self):
        return self.name

class AlertHistory(models.Model):
    definition   = models.ForeignKey(AlertDef)
    startTime    = models.DateTimeField()
    endTime      = models.DateTimeField(null=True)

#Generic Foreign Keys won't work for us, we still need to check
#    object_type = models.ForeignKey(ContentType)
#    object_id = models.PositiveIntegerField()
#    object = generic.GenericForeignKey('object_type', 'object_id')

    coordinator  = models.ForeignKey(Coordinator,null=True)
    combiner     = models.ForeignKey(Combiner,null=True)
    inverter     = models.ForeignKey(Inverter,null=True)
    string       = models.ForeignKey(String, null=True)
    installation = models.ForeignKey(Installation)
    checkField   = models.BooleanField() #Used to determine when an alert is done.

