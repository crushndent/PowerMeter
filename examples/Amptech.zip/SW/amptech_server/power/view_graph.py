from django.core.exceptions import ObjectDoesNotExist
from django.http import HttpResponse
from django.template import Context, loader, RequestContext
from django.shortcuts import render_to_response, get_object_or_404, Http404
from django.views.decorators.csrf import csrf_exempt
from amptech_server.power.models import *

import datetime, time, calendar
import json

def duration(time):
    d=time
    intvl=datetime.timedelta(hours=d.hour, minutes=d.minute,seconds=d.second)
    return (datetime.datetime.utcnow()-intvl)

def graph(request, entity, uuid):
    # Set the current time and a default delta
    tnow = datetime.datetime.utcnow()
    # Set for 2 hours Currently - hardcoded.
    delt = datetime.timedelta(hours=2)

    # Configure our default start and end
    start = tnow - delt
    end = tnow

    # See if we've requested different start/end times
    for k in request.REQUEST:
        if k == "start":
            start = datetime.datetime.fromtimestamp(int(request.REQUEST[k]))
        elif k == "end":
            end = datetime.datetime.fromtimestamp(int(request.REQUEST[k]))

    print "date ranges", start.isoformat(), end.isoformat()

    #TODO - THIS IS NOT REALLY INVERTER HISTORY OR SUM OF COMBINERS,
    # THIS IS JUST A SINGLE COMBINER UNDER THE INVERTER
    def build_rt_inverters_graph(inst_uuid):
        to_send = []
        #Allow for one minute window for the last report power information
        newest_rec_time = datetime.time(0,1,0)
        power=0
        voltage =99999999
        current =0
        graph_d = []
        index=0
        inverter_map={}
        invs = Inverter.objects.filter(installation__uuid=inst_uuid).order_by('id')
        for inv in invs:
            m={}
            combiners = Combiner.objects.filter(inverter=inv).order_by('id')
            csh = CombinerHistory.objects.filter(recordTime__gte=duration(newest_rec_time)).\
                filter(combiner__in=combiners).order_by('combiner','recordTime')
            #filter duplicates
            values = csh.values('current', 'voltage', 'combiner_id')
            for ch in values:
                m[ch['combiner_id']]=ch
            #Now we have the newest of each, add these all together 
            #and make a new record for the inverter.
            new_dict={}
            for k,ch in m.iteritems():
                for k,i in ch.iteritems():
                    if (new_dict.has_key(k)):
                        if (k=='current'):
                            new_dict[k]+=i 
                    else:
                        new_dict[k]=i
            #When complete, the new dict(m) has all the keys it needs (voltage and current), and 
            #needs the inverter UUID assigned
            inverter_map[inv.uuid]=new_dict
            inverter_map[inv.uuid]['uuid'] = inv.uuid
            inverter_map[inv.uuid]['name']=inv.name
        for k,ch in inverter_map.iteritems():
            c=ch
            if (c.has_key('voltage')) :
                current = current + c['current']
                if (voltage > c['voltage']):
                    voltage = c['voltage']
                power = power + c['current'] * c['voltage']/1000
                to_send.append( [
                    "<a href='../combiners/"+c['uuid']+"'>"+c['name']+"</a>",
                    c['current'] * c['voltage']/1000,
                    c['voltage'],
                    c['current'], ])
                graph_d.append({
                    'label':c['name'],
                    'color': index,
                    'data': [[c['current']*c['voltage']/1000, index]] } )
            else:
                to_send.append( [
                    "<a href='../combiners/"+c['uuid']+"'>"+c['name']+"</a>",
                    'no report',
                    'no report',
                    'no report' ])
                graph_d.append({
                    'label': c['name'],
                    'color': index,
                    'data': [] } )
            index+=1
        return json.dumps({
            'inst_uuid' : inst_uuid,
            'power': power*.95,
            'voltage': 600,
            'current': power*.95*1000/600,
            'efficiency': 93,
            'dc_power': power,
            'dc_voltage': voltage*.95,
            'dc_current': current,
            'aaData': to_send,
            'graph_d': graph_d })

    def build_rt_combiners_graph(inv_uuid):
        to_send = []
        #Allow for one minute window for the last report power information
        newest_rec_time = datetime.time(0,1,0)
        power=0
        voltage =99999999
        current =0
        graph_d = []
        index=0
        m={}
        names={}
        
        combiners = Combiner.objects.filter(inverter__uuid=inv_uuid).order_by('id')
        for comb in combiners.values('id','name','uuid'):
            names[comb['id']]={'name':comb['name'],'uuid':comb['uuid']}
        print "2:%s"%(datetime.datetime.now())

        csh = CombinerHistory.objects.filter(recordTime__gte=duration(newest_rec_time)).\
            filter(combiner__in=combiners).order_by('combiner','recordTime')
        #Intersect with the complete list of combiners.
        #filter duplicates
        values = csh.values()
        for ch in values:
            m[ch['combiner_id']]=ch
            m[ch['combiner_id']]['name']=names[ch['combiner_id']]['name']
            m[ch['combiner_id']]['uuid']=names[ch['combiner_id']]['uuid']
            
        print "3:%s"%(datetime.datetime.now())

        #Now do a set union
        for k,ch in m.iteritems():
            names[k] = ch
        m=names
        
        for k,ch in m.iteritems():
            c=ch
            if (c.has_key('voltage')) :
                current = current + c['current']
                if (voltage > c['voltage']):
                    voltage = c['voltage']
                power = power + c['current'] * c['voltage']
                to_send.append( [
                    "<a href='../../strings/"+c['uuid']+"'>"+c['name']+"</a>",
                    c['current'] * c['voltage']/1000,
                    c['voltage'],
                    c['current'],
                    c['temperature']  ])
                graph_d.append({
                    'label':c['name'],
                    'color': index,
                    'data': [[c['current']*c['voltage']/1000, index]] } )
            else:
                to_send.append( [
                    "<a href='../../strings/"+c['uuid']+"'>"+c['name']+"</a>",
                    'no report',
                    'no report',
                    'no report',
                    'no report' ])
                graph_d.append({
                    'label': c['name'],
                    'color': index,
                    'data': [] } )
            index+=1
            
        return json.dumps({
            'inv_uuid' : inv_uuid,
            'power': power*.95/1000,
            'voltage': 600,
            'current': power*.95/600,
            'efficiency': 93,
            'dc_power': power/1000,
            'dc_voltage': voltage*.95,
            'dc_current': current,
            'aaData': to_send,
            'graph_d': graph_d })

    def build_rt_strings_graph(c_uuid):
#        from django.db import connection
        to_send = []
        #Allow for one minute window for the last report power information
        newest_rec_time = datetime.time(0,1,0)
        power=0
        voltage =0
        current =0
        graph_d = []
        index=0
        m={}
        names={}
        combhist=CombinerHistory.objects.filter(combiner__uuid=c_uuid).order_by('-recordTime')[:1].get()
        strings = String.objects.filter(combiner__uuid=c_uuid).order_by('id')
        for string in strings.values('id','name','uuid'):
            names[string['id']]={'name':string['name'],'uuid':string['uuid']}

        combin = Combiner.objects.filter(uuid=c_uuid)[:1]
        csh = StringHistory.objects.filter(string__in=strings).\
            filter(recordTime__gte=duration(newest_rec_time)).order_by('string','recordTime')
        #Intersect with the complete list of combiners.
        #filter duplicates
        values = csh.values()
        print "2:%s"%(datetime.datetime.now())
        for ch in values:
            m[ch['string_id']]=ch
            m[ch['string_id']]['name']=names[ch['string_id']]['name']
            m[ch['string_id']]['uuid']=names[ch['string_id']]['uuid']
        print "3:%s"%(datetime.datetime.now())
#        print connection.queries
        #Now do a set union
        for k,ch in m.iteritems():
            names[k] = ch
        m=names
        
        for k,ch in m.iteritems():
            c=ch
            if (c.has_key('current')) :
                current = current + c['current']
                to_send.append( [
                    c['name'],
                    c['current'] * combhist.voltage/1000,
                    combhist.voltage,
                    c['current'] ])
                graph_d.append({
                    'label':c['name'],
                    'color': index,
                    'data': [[c['current']*combhist.voltage/1000, index]] } )
            else:
                to_send.append( [
                    c['name'],
                    'no report',
                    'no report',
                    'no report' ])
                graph_d.append({
                    'label': c['name'],
                    'color': index,
                    'data': [] } )
            index+=1
            
        return json.dumps({
            'comb_uuid' : c_uuid,
            'dc_power': current * combhist.voltage*.95/1000,
            'dc_voltage': combhist.voltage*.95,
            'dc_current': current,
            'aaData': to_send,
            'graph_d': graph_d })

    def build_single_combiner_graph(c_uuid):
        c = get_object_or_404(Combiner, uuid=c_uuid)
        hists = CombinerHistory.objects.filter(
            combiner=c.pk,
            recordTime__gte=start,
            recordTime__lte=end)

        data_p = []

        for h in hists:
            t = int(h.recordTime.strftime("%s"))
            data_p.append([t,h.voltage*h.current/1000])

        return json.dumps([
            { 'label': 'Power', 'data': data_p },

        ])

    def build_combiner_graph(i_uuid):
        combs = Combiner.objects.filter(inverter__uuid=i_uuid)
        all_data=[]
        for acomb in combs:
            hists = CombinerHistory.objects.filter(
                combiner=acomb,
                recordTime__gte=start,
                recordTime__lte=end)
            data_c = []
            for h in hists:
                t = int(h.recordTime.strftime("%s"))
                data_c.append([t,h.current*h.voltage/1000])
            all_data.append({'label': acomb.name, 'data' :data_c})
        return json.dumps(all_data)

    def build_string_graph(c_uuid):
        strings = String.objects.filter(combiner__uuid=c_uuid)
        all_data=[]
        for astring in strings:
            hists = StringHistory.objects.filter(
                string=astring,
                recordTime__gte=start,
                recordTime__lte=end)
            data_c = []
            for h in hists:
                t = int(h.recordTime.strftime("%s"))

                data_c.append([t,h.current])
            all_data.append({'label': astring.name, 'data' :data_c})

        return json.dumps(all_data)

    r = HttpResponse()

    if entity == "inverterrt":
        r.write(build_rt_inverters_graph(uuid))
    elif entity == "combinerrt":
        r.write(build_rt_combiners_graph(uuid))
    elif entity == "stringrt":
        r.write(build_rt_strings_graph(uuid))

    elif entity == "combiner":
        r.write(build_single_combiner_graph(uuid))
    elif entity == "combinerhistory":
        r.write(build_combiner_graph(uuid))
    elif entity == "stringhistory":
        r.write(build_string_graph(uuid))
    else:
        raise Http404

    return r
