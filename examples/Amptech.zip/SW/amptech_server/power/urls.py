from django.conf.urls.defaults import *
from django.conf import settings

urlpatterns = patterns('amptech_server.power.views',
    # Primary stylized views
    (r'^$', 'index'),
    (r'^index/$', 'index'),
    (r'^inverters/$', 'inverters'),
    (r'^combiners/(?P<inv_uuid>[a-fA-F0-9\-]{36})/$', 'combiners'),
    (r'^strings/(?P<comb_uuid>[a-fA-F0-9\-]{36})/$', 'strings'),
    
    # Alerts for any level of the installation.
    (r'^alerts/(?P<entity>[a-zA-Z]+)/(?P<id>[a-fA-F0-9\-]{36})/','alert'),

    # Per item detailed views
    (r'^inverter/(?P<inverter_id>\d+)', 'inverter'),
    (r'^combiner/(?P<inverter_id>\d+)/(?P<combiner_id>\d+)/$', 'combiner'),
    (r'^string/(?P<inverter_id>\d+)/(?P<combiner_id>\d+)/(?P<string_id>\d+)/$', 'string'),

    # Per item data views
    (r'^data/(?P<entity>[a-zA-Z]+)/(?P<uuid>[a-fA-F0-9\-]{36})/', 'data'),
    (r'^graph/(?P<entity>[a-zA-Z]+)/(?P<uuid>[a-fA-F0-9\-]{36})/', 'graph'),

    # Expect an update from a device in JSON format.
    (r'^command/$', 'command'),
    (r'^command/update/$', 'command_update'),
    (r'^command/config/$', 'command_config'),
)
