from django.core.exceptions import ObjectDoesNotExist
from django.http import HttpResponse
from django.template import Context, loader, RequestContext
from django.shortcuts import render_to_response, get_object_or_404, Http404
from django.views.decorators.csrf import csrf_exempt
from amptech_server.power.models import *
from django.db.models import Avg, Max, Min, Count, Sum

from django.db import transaction

import datetime, time, calendar
import json

from view_graph import graph
from view_coords import *

def duration(time):
    d=time
    intvl=datetime.timedelta(hours=d.hour, minutes=d.minute,seconds=d.second)
    return (datetime.datetime.utcnow()-intvl)

# Alert is used to gather alerts at any of three levels
#
# The levels are installation, inverter, and combiner, all of the alerts under each level
# are returned as well as contact information, and time.
def alert(request, entity, id):
    def format_data(alerts):
        data = []
        for a in alerts:
            single_data={}
            single_data[a.id]={}
            single_data[a.id]['alertname']= a.definition.name
            single_data[a.id]['alerttime']=int(a.startTime.strftime("%s"))
            if (a.coordinator != None):
                single_data[a.id]['coordinator_uuid']=a.coordinator.uuid
            if (a.inverter != None):
                single_data[a.id]['inverter_uuid']=a.inverter.uuid
                single_data[a.id]['inverter_id']=a.inverter.id
                single_data[a.id]['inverter_name']=a.inverter.name
            if (a.combiner != None):
                single_data[a.id]['combiner_uuid']=a.combiner.uuid
                single_data[a.id]['combiner_id']=a.combiner.id
                single_data[a.id]['combiner_name']=a.combiner.name
            if (a.string != None):
                single_data[a.id]['string_uuid']=a.string.uuid
                single_data[a.id]['string_id']=a.string.id
                single_data[a.id]['string_name']=a.string.name
            contacts = a.definition.contact.all()
            single_data[a.id]['contacts'] = []
            for cont in contacts:
                single_data[a.id]['contacts'].append(cont.name)
            data.append(single_data)
        return data

    def installation_alerts(id):
        i = Installation.objects.filter(uuid=id)
        alerts = AlertHistory.objects.filter(installation=i, endTime__isnull=True)
        return json.dumps(format_data(alerts), indent=2)

    def inverter_alerts(id):
        i = Inverter.objects.filter(uuid=id)
        alerts = AlertHistory.objects.filter(inverter=i, endTime__isnull=True)
        return json.dumps(format_data(alerts), indent=2)

    def combiner_alerts(id):
        c = Combiner.objects.filter(uuid=id)
        alerts = AlertHistory.objects.filter(combiner=c, endTime__isnull=True)
        return json.dumps(format_data(alerts), indent=2)

    r=HttpResponse()
    
    if entity == "installation":
        r.write(installation_alerts(id))
    elif entity == "inverter":
        r.write(inverter_alerts(id))
    elif entity == "combiner":
        r.write(combiner_alerts(id))
    else:
        raise Http404
    return r


def index(request):
    #Use the first installation only for now.
    inst = Installation.objects.all()[:1]
    combiners = Combiner.objects.filter(installation=inst)
    return render_to_response('index.html', {
        'title': 'Summary View',
        'tagline': 'Welcome to the Solar PV Management System',
        'current_power' : '3.91',
        'power_to_date' : '623.9',
        'location': 'Olympus Mons',
        'system_size': '1.2 MW',
        'time': '08:35 AM',
        'windage': '15 MPH from NW',
        'humidity': '78%',
        'rainfall': '15 mm',
        'sunrise': '07:10 AM EST',
        'trees': '5431',
        'carbon': '9001',
        'miles': '316,123'
    })

def inverters(request):
    inst = Installation.objects.all()[:1]
    return render_to_response('inverters.html', {
        'title': 'Inverter View',
        'tagline': 'Welcome to the Solar PV Management System',
        'inst_uuid' : inst[0].uuid,
    })

def combiners(request, inv_uuid):
    return render_to_response('combiner.html', {
        'title': 'Combiners View',
        'tagline': 'Welcome to the Solar PV Management System',
        'inv_uuid' : inv_uuid,
    })

def strings(request, comb_uuid):
    c = get_object_or_404(Combiner, uuid=comb_uuid)
    inv_uuid = c.inverter.uuid
    return render_to_response('strings.html', {
        'title': 'Strings View',
        'tagline': 'Welcome to the Solar PV Management System',
        'comb_uuid' : comb_uuid,
        'inv_uuid' :  inv_uuid
    })
