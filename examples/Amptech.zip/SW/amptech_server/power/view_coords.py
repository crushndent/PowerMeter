from django.core.exceptions import ObjectDoesNotExist
from django.http import HttpResponse
from django.template import Context, loader, RequestContext
from django.shortcuts import render_to_response, get_object_or_404, Http404
from django.views.decorators.csrf import csrf_exempt
from amptech_server.power.models import *
from django.db import transaction

import datetime, time, calendar
import json



# Command serves two purposed:
#
# 1) The POST request supplies new data about the sensors
#    the client has data about.
# 2) The response contains both the result of the data
#    provided and any other commands that should be run.
@csrf_exempt
def command(request):
    return render_to_response('command.html', {
        'command': 'none'
    }, context_instance=RequestContext(request))

# Updates are sent as JSON objects.
@transaction.commit_manually # Drastiaclly speeds things up.
@csrf_exempt
def command_update(request):
    u = request.POST['u']
    j = json.loads(unicode(u))

    unknown_installations = []
    unknown_inverters = []
    unknown_combiners = []
    unknown_strings = []
    unknown_coordinator=[]

    def each_install(ins):
        u = ins['uuid']
        try:
            i = Installation.objects.get(uuid=u)
        except ObjectDoesNotExist:
            unknown_installations.append(u)
            
    def each_inverter(inv):
        u = inv['uuid']
        try:
            i = Inverter.objects.get(uuid=u)
        except ObjectDoesNotExist:
            unknown_inverters.append(u)

    def each_combiner(cmb):
        u = cmb['uuid']
        try:
            c = Combiner.objects.get(uuid=u)
            c_data = CombinerHistory(combiner    = c,
                                     voltage     = cmb.get('voltage'),
                                     current     = cmb.get('current'),
                                     temperature = cmb.get('temperature'),
                                     recordTime  = datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))
            c_data.save()
        except ObjectDoesNotExist:
            unknown_combiners.append(u)

    def each_string(stn):
        u = stn['uuid']
        try:
            s = String.objects.get(uuid=u)                
            s_data = StringHistory(string     = s,
                                   current    = stn.get('current'),
                                   recordTime = datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))
            s_data.save()
        except ObjectDoesNotExist:
            unknown_strings.append(u)
    def each_coord(coord):
        try:
            #Update the report time of the coordinator!
            c=Coordinator.objects.get(uuid=coord)
            c.reportTime = datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
            c.save()
        except ObjectDoesNotExist:
            unknown_coordinator.append(coord)
    
    each_install({'uuid' : j.get('installation')})
    
    each_coord(j.get('coordinator'))

    for inv in j.get('inverters'):
        each_inverter(inv)

    for cmb in j.get('combiners'):
        each_combiner(cmb)

    for stn in j.get('strings'):
        each_string(stn)

    transaction.commit()

    return HttpResponse(json.dumps({
        'installation': j['installation'],
        'inverters': len(j['inverters']),
        'combiners': len(j['combiners']),
        'strings': len(j['strings']),
        'unknown_installations': unknown_installations,
        'unknown_inverters': unknown_inverters,
        'unknown_combiners': unknown_combiners,
        'unknown_strings': unknown_strings,
        'unknown_coordinator':unknown_coordinator
    }))

# Configurations are sent as JSON objects.
@transaction.commit_manually
@csrf_exempt
def command_config(request):
    u = request.POST['c']
    j = json.loads(unicode(u))

    #look for the record in the DB, and if there is such an object,
    #if it doesn't exist, then add it.
    inst_json = j.get('installation')
    try:
        inst = Installation.objects.get(uuid=inst_json['uuid'])            
    except Installation.DoesNotExist:
        inst = Installation(uuid=inst_json['uuid'],name=inst_json['name']) 
        inst.save()    
    
    coord = inst_json.get('coordinator')
    try:
        coord_obj = Coordinator.objects.get(uuid=coord['uuid'])            
    except Coordinator.DoesNotExist:
        coord_obj = Coordinator(uuid=coord['uuid'], installation=inst, \
            reportTime= datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")) 
        coord_obj.save()    
    
    for inv_json in coord.get('inverters'):
        try:
            inv = Inverter.objects.get(uuid=inv_json['uuid'])
        except Inverter.DoesNotExist:
            inv = Inverter(uuid=inv_json['uuid'],name=inv_json['name'], \
                coordinator=coord_obj, installation=inst)
        inv.save()

    for c_json in coord.get('combiners'):
        c_uuid = c_json.get('uuid')
        try:
            c = Combiner.objects.get(uuid=c_uuid)                
        except Combiner.DoesNotExist:
            c = Combiner(uuid=c_uuid,name=c_json.get('name'), \
                coordinator=coord_obj, installation=inst)
        #Remove the line below for real production.
        c.inverter = inv
        c.save()
        for s_json in c_json.get('strings'):
            try:
                s = String.objects.get(uuid=s_json['uuid'])                        
            except String.DoesNotExist:
                s = String(uuid=s_json['uuid'],name=s_json['name'])
            s.combiner = c
            s.save()                        

    transaction.commit()

    return HttpResponse('OK')

def data(request, entity, uuid):
    def build_combiner_data(c_uuid):
        c = get_object_or_404(Combiner, uuid=c_uuid)
        hists = CombinerHistory.objects.filter(combiner=c.pk)

        records = []
        for h in hists:
            records.append({
                'voltage': h.voltage,
                'temperature': h.temperature,
                'recordTime': calendar.timegm(h.recordTime.timetuple())
            })

        data = {
            'uuid' : c_uuid,
            'data' : records
        }

        return json.dumps(data)

    def build_string_data(s_uuid):
        s = get_object_or_404(String, uuid=s_uuid)
        hists = StringHistory.objects.filter(string=s.pk)
        records = []
        for h in hists:
            records.append({
                'current': h.current,
                'recordTime': calendar.timegm(h.recordTime.timetuple())
            })
        data = {
            'uuid': s_uuid,
            'data': records
        }
        return json.dumps(data)
    r = HttpResponse()
    if entity == "combiner":
        r.write(build_combiner_data(uuid))
    elif entity == "string":
        r.write(build_string_data(uuid))
    else:
        raise Http404
    return r
