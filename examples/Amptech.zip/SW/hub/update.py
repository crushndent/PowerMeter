#!/usr/bin/python

import sys

zip = "WEB/python/modules.zip"

sys.path.append(zip)

import os
import json
import datetime
import urllib2
from urllib import urlencode
from socket import *
import time
import zigbee
import select

# Our modules
import config

#config files
LOCAL_CONFIG_PATH = 'WEB/python/local_config.txt'
IP_ADDRESS = '192.168.1.11:8000'


#what rate do we want to look for data updates (seconds)
UPDATE_RATE=4

#amount of time to wait between sending command
#on a socket and reading the socket for a reply - in seconds
RESPONSE_DELAY = 2

def rqst_command():
    try:
        rq = urllib2.Request('http://' + IP_ADDRESS + '/power/command/')
        r = urllib2.urlopen(rq)
        print r.read()
        print r.info()
    except urllib2.HTTPError, e:
        print e.read()
        # Do not raise the exception again because it won't be caught.
        # Keep the program running.

def send_stats(obj):
    try:
        params = urlencode({'u': json.write(obj)})
        rq = urllib2.Request('http://' + IP_ADDRESS + '/power/command/update/', params)
        r = urllib2.urlopen(rq)
        ret_val = r.read()        

        j = json.read(ret_val)
        print len(j.get('unknown_installations')) 
        print len(j.get('unknown_inverters'))  
        print len(j.get('unknown_combiners')) 
        print len(j.get('unknown_strings'))
        print len(j.get('unknown_coordinator'))

        m = max(map(len, [j.get('unknown_installations'),
                          j.get('unknown_inverters'),
                          j.get('unknown_combiners'),
                          j.get('unknown_strings'),
                          j.get('unknown_coordinator')]))
        print m
        if m > 0:
            print "sending configuration"
            db_cfg= get_config()
            send_config(db_cfg)
    except urllib2.HTTPError, e:
        print e.read()
    except Exception, e:
        print e
        pass
def send_config(obj):
    try:
        params = urlencode({'c': json.write(obj)})
        rq = urllib2.Request('http://' + IP_ADDRESS + '/power/command/config/', params)
        r = urllib2.urlopen(rq)
        print r.read()
    except urllib2.HTTPError, e:
        print e.read()
    except Exception, e:
        pass

def request(jsonstr):
    # Get the command
    rqst_command()
    try:
        params = urlencode({'u': jsonstr})
        rq = urllib2.Request('http://' + IP_ADDRESS + '/power/command/update/', params)
        r = urllib2.urlopen(rq)
        print r.read()

    except urllib2.HTTPError, e:
        print e.read()
    except Exception, e:
        pass

def g_data(db_cfg):

    def get_comb_data(mac,cmd):
        valid_data=False
    
        #print "mac:%s" % mac
        dest = (mac, 0x00, 0xc105, 0x11)
        payload = ""

        # Create the socket, datagram mode, proprietary transport:
        sd = socket(AF_ZIGBEE, SOCK_DGRAM, ZBS_PROT_TRANSPORT) 
         
        # Bind to endpoint 0x00 for 802.15.4
        sd.bind(("", 0x00, 0, 0))

        # Set it nonblocking
        sd.setblocking(0)

        #could implement some retry strategy on the following block
        sd.sendto("%s\r" % cmd, 0, dest)
        #print "before sleep"
        
        #For TESTing
        #time.sleep(5)

        try:
            rlist=[sd]
            rlist,wlist,xlist = select.select(rlist,[],[],RESPONSE_DELAY)
            if (sd in rlist):
                payload, src_addr = sd.recvfrom(255)
                print "payload %s, addr %s" %(payload, src_addr)
            #TODO add some more checking here or down lower to see if the data you
            #received was from the source that you expected.
            #For now, the only way to check this would be a mapping between the "command"
            #and the first data field (i.e. 1=BA, 2=BB, 3=BC, etc)
            #For the future it would be best to have the mac as part of the data stream
            #that is returned.  You could use the short address field, which is returned
            #in src_addr above, but then the customer would have to program those in.

            #TODO: could also add some checking to see if the number of data items you 
            #received were what was expected.  May have to add that data item to the
            #"local_config.txt" file.  As it is, the code that depends on this data will
            #crash if the number of data items do not match what it is expecting to receive.
            return payload
        except Exception, e:
            # ends up here if no response
            #TODO, add more checking to see what kind of socket error...
            #there may be other errors besides the read time out. 
            pass

    dat = {
        'installation': db_cfg.get('installation').get('uuid'),
        'coordinator': db_cfg.get('installation').get('coordinator').get('uuid'),
        'inverters': [],
        'combiners': [],
        'strings': []
    }

    for i in db_cfg.get('installation').get('coordinator').get('inverters'):
        dat['inverters'].append ({'uuid' : i.get('uuid')})        
    for c in db_cfg.get('installation').get('coordinator').get('combiners'):
        payload=""
        #get the db_config stored uuid for this combiner
        c_uuid = c.get('uuid')
        #lookup the mac, node_cmd from the local_config based on uuid
        comb_mac = c.get('mac')
        comb_cmd = c.get('node_cmd')
        #get the data from the combiner
        try:
            payload = get_comb_data(comb_mac, comb_cmd)
            #parse the data
            #convert to a list, and get rid of last field
            payload = payload.split(",")
            payload.pop()
            #pull out the temp and voltage
            c_temp = float(payload.pop())
            c_volt = float(payload.pop())*10

            #reverse the order of data, and pop off the node id field
            payload.reverse()
            payload.pop()
            c_current=0
            for s in c.get('strings'):
                current = float(payload.pop())/10
                c_current += current
                dat['strings'].append({
                    'uuid': s.get('uuid'),
                    'current': current,
                    'recordTime': datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
                })
                
            dat['combiners'].append({
                'uuid': c_uuid,
                'voltage': c_volt,
                'current': c_current,
                'temperature': c_temp,
                'recordTime': datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
            })
                
        except Exception, e:
            print type(e)
            print e.args
            print e
            #TODO more work to do here for when no data comes back.
            #could do a retry on the same mac/cmd.
            print "error!"
    return dat

def get_config():
    h = open(LOCAL_CONFIG_PATH,'r')
    k = json.read(h.read())
    h.close()
    return k

if __name__ == '__main__':
    if not os.path.exists(LOCAL_CONFIG_PATH):
        config.create()
    k = get_config()
    while True:
        send_stats(g_data(k))
        print "OK"
        time.sleep(UPDATE_RATE)

