#!/usr/bin/python


import sys

zip = "WEB/python/modules.zip"

sys.path.append(zip)

import json
import uuid
from socket import *
import time
import zigbee
import select

LOCAL_CONFIG_PATH = 'WEB/python/local_config.txt'
SERVER_IP = '0.0.0.0'

#this is the number of "commands" sent to 
#each zigbee node to see if it responds to it
MAX_COMBINERS = 6

#amount of time to wait between sending command
#on a socket and reading the socket for a reply
RESPONSE_DELAY = 2

def g_config(lc):
    
    def g_strings(c):
        for i in range(0,c):
            yield {
                'uuid': unicode(uuid.uuid4()),
                'name': 'string-%c' % (65+i)
            }

    def g_combiners(lc):
        combiners = []
        try:
            # Perform a node discovery:
            node_list = zigbee.getnodelist() 

            # Create the socket, datagram mode, proprietary transport:
            sd = socket(AF_ZIGBEE, SOCK_DGRAM, ZBS_PROT_TRANSPORT) 
             
            # Bind to endpoint 0x00 for 802.15.4
            sd.bind(("", 0x00, 0, 0))

            # Set it nonblocking
            sd.setblocking(0)
        except Exception, e:
            return
        
        # Walk the list of nodes, looking for "end" devices
        for node in node_list : 
            #may want to change this, depending on implementation.
            if node.type != "coordinator" :
#                print "Label: %s" % (node.label)
#                print "Type: %s" % (node.type)
#                print "Address: %s" %(node.addr_extended)
                # parse out the address
                print node.addr_extended
                dest_addr = node.addr_extended[1:-2] + "!"
                dest = (dest_addr, 0x00, 0xc105, 0x11)
                
                # try sending commands to the device, looking for a reply
                for cb_command in range (1,MAX_COMBINERS+1) :
                    sd.sendto("%d\r" % cb_command, 0, dest)
                    try:
                        rlist=[sd]
                        #wait for the socket to read or timeout waiting.
                        rlist,wlist,xlist = select.select(rlist,[],[],RESPONSE_DELAY)
                        if (sd in rlist):
                            found=False
                            payload = ""
                            payload, src_addr = sd.recvfrom(255)
                            #TODO add some more checking here or down lower to see if the data you
                            #received was from the source that you expected.
                            #For the future it would be best to have the MAC as part of the data stream
                            #that is returned.  

                            # if we have a valid payload, parse it to get:
                            #	* the number of "strings"
                            print "mac:%s command:%d  data:%s" % (dest_addr,cb_command,payload)
                            for node in lc['combiners']:
                                #TEST - to touchup later - use filter() method instead of iterating
                                if str(dest_addr) in node.values():
                                    #TEST ONLY - change for new protocol - remove one line below
                                    if str(cb_command) in node.values():
                                        #the node was already in the config, use the existing combiner structure.
                                        #this also contains all of the strings.
                                        found=True
                                        print "**combiner node exists"
                                        yield node 
                                        break
                            if (found==False):
                                string_count = payload.count(",") - 3
                                #Node id should be the first field - when changes are made, this will go away.
                                node_id = payload[0:payload.find(",")]
                                yield {
                                    'uuid': unicode(uuid.uuid4()) ,
                                    'name': 'combiner-%s' % node_id,
                                    'strings': list(g_strings(string_count)),
                                    'mac' : str(dest_addr),
                                    'node_cmd' : str(cb_command) 
                                }   
                            
                            #TEST if we only expect one response per address, then uncomment the next line
                            #break
                    except Exception, e:
                        print e
                        #TODO, add more checking to see what kind of socket error...
                        # Could not parse the data, so it winds up here, and we have no data for this node.
                        pass
                        
        sd.close()

    def g_inverters(lc):
        found=False
        for inv in lc['inverters']:
            print inv.values()
            #TEST - for now - harcoded to 'inverter-A' below
            if "inverter-A" in inv.values():
                print "**inverter node exists"
                found=True
                yield inv
                break
        if (found==False):
            yield {
                'uuid': unicode(uuid.uuid4()),
                'name': 'inverter-%c' % (65),
            }
    
    #Check for configuration information in the existing file.
    coord_uuid = False
    if ('installation' in lc):
        try:
            lc = lc['installation']
            inst_uuid = lc['uuid']
            inst_name = lc['name']
            server_ip = lc['server_ip']
            coord_uuid = lc['coordinator']['uuid']
            lc = lc['coordinator']
        except KeyError, e:
            pass
    if (coord_uuid == False):
        inst_uuid = unicode(uuid.uuid4())
        inst_name = unicode("Name this install")
        coord_uuid = unicode(uuid.uuid4())
        server_ip = SERVER_IP
    
    return {
        'installation' : {
            'uuid' : inst_uuid,
            'name': inst_name,
            'server_ip':server_ip,
            'coordinator' : {
                'uuid' : coord_uuid,
                'inverters' : list(g_inverters(lc)),
                'combiners' : list(g_combiners(lc))
    }  }  }

def create():
    #check if the LOCAL_CONFIG file exists.
    # If the file exists, then read it in. Use the file so that nodes that have already been created don't
    # get a new UUID. Also, we are going to use the installation UUID to make sure that these get 
    # in the right place.
    try:
        h = open(LOCAL_CONFIG_PATH, 'r')
        lc = json.read(h.read())
        h.close()    
    except Exception,e:
        print "No configuration file!\n#Using new settings#"
        #make a bare structure so that later calls don't fail.
        lc = {
        'installation' : {
            'uuid' : 0,
            'name': 0,
            'server_ip': SERVER_IP,
            'coordinator' : {
                'uuid' : 0,
                'inverters' : {},
                'combiners' : {} } } }        
    k = g_config(lc)
    k = json.write(k)
    h = open(LOCAL_CONFIG_PATH, 'w')
    h.write(k)
    h.close()

if __name__ == '__main__':
    create()
    print "Wrote local config file to %s" % LOCAL_CONFIG_PATH
