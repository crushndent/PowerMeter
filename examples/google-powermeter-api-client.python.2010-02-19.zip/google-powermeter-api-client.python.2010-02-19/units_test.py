#!/usr/bin/python2.4
# Copyright 2008 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Tests for the units module."""

import unittest

import units


class UnitTest(unittest.TestCase):
  def testStr(self):
    self.assertEquals('s', str(units.SECOND))
    self.assertEquals('W', str(units.WATT))
    self.assertEquals('J', str(units.JOULE))
    self.assertEquals('kW h', str(units.KILOWATT_HOUR))

  def testRepr(self):
    self.assertEquals('<Unit: s>', repr(units.SECOND))
    self.assertEquals('<Unit: W>', repr(units.WATT))
    self.assertEquals('<Unit: J>', repr(units.JOULE))
    self.assertEquals('<Unit: kW h>', repr(units.KILOWATT_HOUR))

  def testMul(self):
    self.assertEquals(units.JOULE, units.WATT * units.SECOND)
    self.assertEquals(units.JOULE, units.SECOND * units.WATT)

  def testRmul(self):
    quantity = 4 * units.WATT
    self.assertEquals(4, quantity.value)
    self.assertEquals(units.WATT, quantity.unit)

  def testDiv(self):
    self.assertEquals(units.WATT, units.JOULE / units.SECOND)

  def testIsConvertibleTo(self):
    self.assertEquals(True, units.KILOWATT_HOUR.IsConvertibleTo(units.JOULE))
    self.assertEquals(True, units.JOULE.IsConvertibleTo(units.KILOWATT_HOUR))
    self.assertEquals(False, units.JOULE.IsConvertibleTo(units.SECOND))


class QuantityTest(unittest.TestCase):
  def testEq(self):
    self.assertEquals(True, 4 * units.WATT == 4 * units.WATT)
    self.assertEquals(False, 4 * units.WATT == 5 * units.WATT)
    self.assertEquals(False, 4 * units.WATT == 4 * units.JOULE)

  def testStr(self):
    self.assertEquals('4 W', str(4 * units.WATT))
    self.assertEquals('2.5 kW h', str(2.5 * units.KILOWATT_HOUR))

  def testRepr(self):
    self.assertEquals('<Quantity: 4 W>', repr(4 * units.WATT))
    self.assertEquals('<Quantity: 15 s>', repr(15 * units.SECOND))

  def testNeg(self):
    self.assertEquals(
        units.Quantity(-5, units.WATT), -units.Quantity(5, units.WATT))
    self.assertEquals(
        2 * units.JOULE, -(-(2 * units.JOULE)))

  def testAdd(self):
    self.assertEquals(
        3 * units.SECOND, (1 * units.SECOND) + (2 * units.SECOND))
    self.assertEquals(
        43 * units.JOULE, (7 * units.JOULE) + (1e-5 * units.KILOWATT_HOUR))

  def testSub(self):
    self.assertEquals(
        4 * units.SECOND, (13 * units.SECOND) - (9 * units.SECOND))
    self.assertEquals(
        -29 * units.JOULE, (7 * units.JOULE) - (1e-5 * units.KILOWATT_HOUR))

  def testDiv(self):
    self.assertEquals(4 * units.WATT, (4 * units.JOULE) / units.SECOND)
    self.assertEquals(2 * units.WATT, (4 * units.JOULE) / (2 * units.SECOND))
    self.assertEquals(10, (1e-4 * units.KILOWATT_HOUR) / (36 * units.JOULE))

  def testMul(self):
    self.assertEquals(18 * units.JOULE, (3 * units.JOULE) * 6)
    self.assertEquals(3 * units.JOULE, (3 * units.WATT) * units.SECOND)
    self.assertEquals(18 * units.JOULE, (3 * units.WATT) * (6 * units.SECOND))

  def testRmul(self):
    self.assertEquals(18 * units.JOULE, 6 * (3 * units.JOULE))
    self.assertEquals(3 * units.JOULE, units.SECOND * (3 * units.WATT))

  def testConvertTo(self):
    self.assertEquals(
        3600 * units.JOULE,
        (0.001 * units.KILOWATT_HOUR).ConvertTo(units.JOULE))
    self.assertEquals(
        7200 * units.SECOND, (2 * units.HOUR).ConvertTo(units.SECOND))

  def testIsConvertibleTo(self):
    self.assertEquals(True, (2 * units.HOUR).IsConvertibleTo(units.SECOND))
    self.assertEquals(False, (2 * units.JOULE).IsConvertibleTo(units.SECOND))


if __name__ == '__main__':
  unittest.main()
