#!/usr/bin/python2.4
# Copyright 2008 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Splits a batch-post-event XML file into smaller subfiles where each
subfile is of a reasonable size (if there are too many events in a single
upload, the upload will fail).

The input file must be formatted so that each <feed>, </feed>, <entry>,
and </entry> tag is on a line by itself.

The output is written to a series of files named <filename>_00000,
<filename>_00001, <filename>_00002, etc. where <filename> is the name
of the input file.
"""

__author__ = 'dbanks@google.com (Doug Banks)'

from optparse import OptionParser
import os
import re
import socket
import subprocess
import sys
import time

ENTRIES_PER_FILE = 100
XML_PI_PATTERN = re.compile(r'^\s*<\?xml\b')
FEED_START_OR_END_PATTERN = re.compile(r'^\s*</?feed\b')
ENTRY_END_PATTERN = re.compile(r'^\s*</entry\b')

def ProduceFile(lines_for_file, file_count, filename):
  """Dump these entries into a file to be uploaded."""

  adjusted_filename = "%s_%05d" % (filename, file_count)
  file = open(adjusted_filename, "w")
  file.write("""\
<?xml version="1.0" encoding="utf-8"?>
<feed xmlns="http://www.w3.org/2005/Atom" xmlns:meter="http://schemas.google.com/meter/2008" xmlns:batch="http://schemas.google.com/gdata/batch">
%s
</feed>
""" % ''.join(lines_for_file))
  file.close()
  print >>sys.stderr, "wrote %s" % adjusted_filename


if __name__ == '__main__':
  # Set up the command-line option parser.
  op = OptionParser('%prog <filename> [options]\n\n' +
                    __doc__ + '''
arguments:
  <filename>            name of the file to read in and split up''')

  # Parse the command-line options.
  options, args = op.parse_args()
  if len(args) != 1:
    op.exit(1, op.format_help())
  filename = args[0]

  lines = open(filename, 'r').readlines()
  file_count = 0
  entry_count = 0

  lines_for_file = []

  for line in lines:
    if XML_PI_PATTERN.match(line):
      # Skip the <?xml> tag.
      continue

    if FEED_START_OR_END_PATTERN.match(line):
      # Skip <feed> and </feed> tags.
      continue

    # Collect lines that belong to entries.
    lines_for_file.append(line)

    if ENTRY_END_PATTERN.match(line):
      # At the end of an entry, update and check the entry count.
      entry_count += 1
      if entry_count >= ENTRIES_PER_FILE:
        ProduceFile(lines_for_file, file_count, filename)
        file_count += 1
        # reset, we are starting a new file now.
        lines_for_file = []
        entry_count = 0
  if entry_count > 0:
    ProduceFile(lines_for_file, file_count, filename)
