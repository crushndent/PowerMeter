#!/usr/bin/python2.4
# Copyright 2009 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Creates or updates a Google PowerMeter variable.

All requests require an AuthSub session token that is authorized to write to
the specified variable.
"""

from optparse import OptionParser
import re

import google_meter

if __name__ == '__main__':
  # Set up the command-line option parser.
  op = OptionParser(
      '%prog <token> <user-ID> <variable-ID> <location>\n\n' +
      __doc__ + '''
arguments:
  <token>               AuthSub token for GData requests (required)
  <user-ID>             20-digit user ID of the new variable's owner (required)
  <variable-ID>         variable ID for the new variable (required)
  <location>            location for the new variable (e.g. city, state, postal
                        code, country; required)''')
  op.add_option('', '--service', metavar='<URI>',
                help='URI prefix of the GData service to contact '
                     '(default: https://www.google.com/powermeter/feeds)')
  op.add_option('', '--name', metavar='<string>',
                help='name for the new variable (default: "Variable <ID>")')
  op.add_option('', '--text', metavar='<string>',
                help='text for the new variable (default: "Variable <ID>")')
  op.add_option('', '--type', metavar='<string>',
                help='type for the new variable'
                     '(default: electricity_consumption)')
  op.add_option('', '--unit', metavar='<string>',
                help='unit for the new variable (default: "kW h")')
  op.add_option('', '--cumulative', action='store_true',
                help='set the cumulative flag on the new variable')
  op.add_option('', '--durational', action='store_true',
                help='set the durational flag on the new variable')
  op.add_option('-v', '--verbose',
                action='store_const', const=2, dest='log_level',
                help='display HTTP requests and replies')
  op.set_defaults(service='https://www.google.com/powermeter/feeds',
                  log_level=1, type='electricity_consumption', unit='kW h')

  # Parse and validate the command-line options.
  options, args = op.parse_args()
  if len(args) != 4:
    op.exit(1, op.format_help())

  token, user_id, variable_id, location = args

  if not re.match(r'^\d{20}$', user_id):
    op.error('%r is not a 20-digit user ID' % user_id)
  if not re.match(r'^[\w.-]+$', variable_id):
    op.error('%r is not a valid variable ID' % variable_id)

  # Set up access to the GData service.
  log = google_meter.Log(options.log_level)
  service = google_meter.Service(token, options.service, log=log)

  # Create and post the variable.
  variable = google_meter.Variable(
      user_id, user_id, variable_id,
      options.name or 'Variable %s' % variable_id,
      options.text or 'Variable %s' % variable_id,
      location, options.type, options.unit,
      options.cumulative, options.durational)
  service.PostEntity(variable)
