#!/usr/bin/python2.4
# Copyright 2009 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Posts meter readings to a Google PowerMeter variable.

Readings are read from standard input, one per line.  Use command-line
options to specify how the times for the readings are determined:

  - By default, the time of each reading is that actual clock time that
    the line of input is read.  (This can be useful for interactive testing
    or for data being piped from a process that emits numbers periodically.)
    There is a 1-second delay after reading each line, which you can change
    with the "--period" option.

  - Alternatively, you can generate regularly spaced timestamps in the past,
    using the "--backdate" option.

  - Alternatively, you can obtain the times for the readings from another
    field on each line of input, using the "--time_column" option.  The
    time should be given as a Unix time (seconds since January 1, 1970,
    00:00:00 UTC) or as an RFC 3339 timestamp (yyyy-mm-ddThh:mm:ssZ).

Each line of input is split into columns; by default, the first column is
assumed to contain the meter reading in kilowatt-hours.  Thus, in the
default case, you can simply enter one number on each line.

You can use the "--reading_column", "--time_column", and "--initial_column"
options to set which columns of the input to examine.  You can also use the
"--unit" option to set the units of the readings to "W" or "kW h".

If you are posting to a durational variable, specify "--durational" to get
durational measurements.  Otherwise, instantaneous measurements are posted.

Here are a few examples:

  - Post register readings in kW h, in realtime as you enter them:
    ./post_readings.py $TOKEN $VARIABLE --period=0

  - Post interval readings in W, from a file, one per second:
    ./post_readings.py $TOKEN $VARIABLE --unit=W --interval < file.txt

  - Post historical readings for the past day from a file, one per minute:
    ./post_readings.py $TOKEN $VARIABLE --period=60 --backdate=1440 < file.txt

  - Post register readings from a file where each line contains the reading
    time followed by a tab and then the reading value in kW h:
    ./post_readings.py $TOKEN $VARIABLE \\
        --split_on_tab --time_column=1 --reading_column=2 < file.txt

In the above examples, $TOKEN is an AuthSub token, such as:
    TOKEN="Cj0Pb5WiVh2TstWrxS"
and $VARIABLE is the entity path of a variable, such as:
    VARIABLE="/user/12345678901234567890/12345678901234567890/variable/foo.c1"

All requests require an AuthSub session token that is authorized to write to
the specified variable.
"""

from optparse import OptionParser
import os
import re
import socket
import sys
import time

import google_meter
import rfc3339
import units

if __name__ == '__main__':
  # Set up the command-line option parser.
  op = OptionParser('%prog <token> <variable>\n\n' + __doc__ + '''
arguments:
  <token>               AuthSub token for GData requests (required)
  <variable>            entity path of a PowerMeter variable (required)''')
  op.add_option('', '--service', metavar='<URI>',
                help='URI prefix of the GData service to contact '
                     '(default: https://www.google.com/powermeter/feeds)')
  op.add_option('', '--unit', metavar='<symbol>',
                help='units of the measurements being posted (default: kW h)')
  op.add_option('', '--period', metavar='<seconds>', type='int',
                help='period between posts (0 means realtime; default: 1)')
  op.add_option('', '--backdate', metavar='<count>', type='int',
                help='shift the first <count> posts before the current time')
  op.add_option('', '--register', action='store_false', dest='interval',
                help='treat input as register readings (default)')
  op.add_option('', '--interval', action='store_true',
                help='treat input as interval readings')
  op.add_option('', '--durational', action='store_true',
                help='post durational measurements (default: instantaneous)')
  op.add_option('', '--uncertainty', metavar='<kilowatt-hours>', type='float',
                help='uncertainty in measured values (default: 0.1)'),
  op.add_option('', '--time_uncertainty', metavar='<seconds>', type='float',
                help='uncertainty in measured times (default: 0.1)'),
  op.add_option('', '--reading_column', metavar='<column number>', type='int',
                help='column in input data that contains the reading')
  op.add_option('', '--time_column', metavar='<column number>', type='int',
                help='column in input data that contains the time')
  op.add_option('', '--initial_column', metavar='<column number>', type='int',
                help='column in input data that indicates reading is initial')
  op.add_option('', '--split_on_tab', action='store_true',
                help='split input columns by tabs, instead of spaces')
  # The data files we're reading have "initial" columns that are marked
  # when a changeover occurs. But there are times when we may want to input
  # fewer readings from a dense file, say, by reading only every 100th line
  # (e.g.  sed -n '0~100p' readingsFile | post_readings.py ...)
  # In this case, we can let this script do some "initial" inference
  op.add_option('', '--infer_initial', action='store_true',
                help='infer that a reading is initial by seeing if the read '
                'value is less than the previous value, but the time is more '
                'recent')
  # This option was added to deal with files that have some recorded times that
  # are out of whack because the clock was being fiddled with.
  op.add_option('', '--skip_nonincreasing_times', action='store_true',
                help='skip readings with times that are earlier than the '
                'previous reading\'s time')
  op.add_option('', '--min_time_between_readings',
                metavar='<minutes>', type='int',
                help='omit readings that differ in time from the preceding '
                'reading by less than this value')
  op.add_option('', '--last_successful_post_file', metavar='<filename>',
                help='the time and value of the last successful post is saved '
                'to this file, and on startup this file is checked if it exists'
                ' to determine whether the first event should be marked as '
                'initial.')
  op.add_option('-b', '--batch', action='store_true',
                help='post events in batches insted of individually')
  op.add_option('-v', '--verbose',
                action='store_const', const=2, dest='log_level',
                help='display HTTP requests and replies')
  op.set_defaults(service='https://www.google.com/powermeter/feeds',
                  log_level=1, unit='kW h', period=1, backdate=0,
                  interval=False, durational=False, uncertainty=0.1,
                  time_uncertainty=0.1, reading_column=1, time_column=0,
                  initial_column=0, min_time_between_readings=0, batch=False)

  # Parse and validate the command-line options.
  options, args = op.parse_args()
  if len(args) != 2:
    op.exit(1, op.format_help())
  token, variable = args

  last_column = max(options.time_column, options.reading_column)
  if 0 < options.initial_column <= last_column:
    op.error('initial column must be come after all other columns')

  if (options.min_time_between_readings != 0 and
      not options.skip_nonincreasing_times):
    op.error('The min_time_between_readings setting is only valid when '
             'skip_nonincreasing_times is also enabled.')

  if not re.match(r'^/user/(\d{20})/([\w.-]+)/variable/([\w.-]+)$', variable):
    op.error('%r is not a valid variable path' % variable)

  if options.unit not in units.units_by_symbol:
    op.error('%r is not a recognized unit symbol' % options.unit)
  unit = units.units_by_symbol[options.unit]

  if options.interval:
    prompt = 'interval reading (%s): ' % unit
  else:
    prompt = 'register reading (%s): ' % unit

  min_seconds_between_readings = 60 * options.min_time_between_readings
  last_value = None
  if options.time_column == 0 and options.backdate:
    last_time = time.time() - options.backdate * options.period
  else:
    last_time = None

  if (options.last_successful_post_file and
      os.path.exists(options.last_successful_post_file)):
    f = open(options.last_successful_post_file)
    last_time, last_value = map(float, f.readline().split())

  if options.split_on_tab:
    field_separator = '\t'
  else:
    field_separator = None

  # Set up access to the GData service.
  log = google_meter.Log(options.log_level)
  service = google_meter.Service(token, options.service, log=log)
  if options.batch:
    service = google_meter.BatchAdapter(service)
  meter = google_meter.Meter(
      service, variable, options.uncertainty * units.KILOWATT_HOUR,
      options.time_uncertainty, options.durational, last_time)

  # Read and post measurements.
  successful_posts = 0
  while 1:
    if options.log_level > 1 or sys.stdin.isatty():
      print

    # In interactive mode, show the prompt.
    if sys.stdin.isatty():
      sys.stdout.write(prompt)
      sys.stdout.flush()

    # Get the next measurement.
    line = sys.stdin.readline()
    initial = False
    if not line:
      break
    try:
      assert line.split(), 'no text found'
      fields = line.split(field_separator)
      value = float(fields[options.reading_column - 1])
      if options.time_column > 0:
        try:
          read_time = float(fields[options.time_column - 1])
        except ValueError:
          read_time = rfc3339.FromTimestamp(fields[options.time_column - 1])
    except (AssertionError, IndexError, ValueError), e:
      print '-- %s: %s' % (e.__class__.__name__, e)
      continue

    if options.time_column == 0:
      # Advance to the time when we're supposed to post the measurement.
      if options.period and last_time is not None:
        # In periodic mode (period > 0), use the scheduled periodic time.
        read_time = last_time + options.period
        time.sleep(max(0, read_time - time.time()))
      else:
        # In realtime mode (period == 0), use the actual time.
        read_time = time.time()

    # Handle some edge cases.
    if options.initial_column > 0 and len(fields) >= options.initial_column:
      meter.Reset()

    if options.infer_initial and last_value > value and last_time < time:
      meter.Reset()

    if options.skip_nonincreasing_times and last_time is not None:
      if read_time < last_time:
        continue
      if (read_time - last_time) < min_seconds_between_readings:
        continue

    # Post the measurement.
    try:
      if options.interval:
        meter.PostIntervalReading(
            value * unit, 0.1 * units.KILOWATT_HOUR, last_time, read_time)
      else:
        meter.PostRegisterReading(
            value * unit, 0.1 * units.KILOWATT_HOUR, read_time)
    except (IOError, socket.error), e:
      print '-- %s: %s' % (e.__class__.__name__, e)
    else:
      last_time = read_time
      last_value = value
      if not options.batch:
        successful_posts += 1
        if options.last_successful_post_file:
          f = open(options.last_successful_post_file, 'w')
          print >> f, '%f %f' % (last_time, last_value)
          f.close()

  # In interactive mode, leave a blank line after the last prompt.
  if sys.stdin.isatty():
    print

  if options.batch:
    service.Flush()
    if options.last_successful_post_file:
      f = open(options.last_successful_post_file, 'w')
      print >> f, '%f %f (batch)' % (last_time, last_value)
      f.close()
  else:
    print '\nPosted %d reading%s.' % (
        successful_posts,
        google_meter.IncludeIfTrue(successful_posts != 1, 's'))
