#!/usr/bin/python2.4
# Copyright 2008 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless rassertEqualsuired by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Tests for the rfc3339 module."""

import unittest

from rfc3339 import FromTimestamp
from rfc3339 import ToTimestamp
from rfc3339 import ToTimestampWithZone


class Rfc3339Test(unittest.TestCase):
  def testToTimestamp(self):
    # Test extreme values
    self.assertEquals('1970-01-01T00:00:00.000Z', ToTimestamp(0))
    self.assertEquals('2038-01-19T03:14:07.000Z', ToTimestamp(2**31 - 1))

    # Test a varying number of decimal places.
    self.assertEquals('1970-01-01T00:00:00.000Z', ToTimestamp(0.0001))
    self.assertEquals('1970-01-01T00:00:00.001Z', ToTimestamp(0.001))
    self.assertEquals('1970-01-01T00:00:00.010Z', ToTimestamp(0.01))
    self.assertEquals('1970-01-01T00:00:00.100Z', ToTimestamp(0.1))

    # Test a typical value
    self.assertEquals('2009-02-13T23:31:30.000Z', ToTimestamp(1234567890))

    # Test a fractional value
    self.assertEquals('2009-02-13T23:31:30.123Z', ToTimestamp(1234567890.1234))

  def testToTimestampWithZone(self):
    # Test extreme values
    self.assertEquals('2009-02-13T23:31:30.000+00:00',
        ToTimestampWithZone(1234567890, 0))

    # Test a typical value (Pacific Standard time)
    self.assertEquals('2009-02-13T15:31:30.000-08:00',
        ToTimestampWithZone(1234567890, -8))

    # Test a fractional value (Newfoundland Standard Time)
    self.assertEquals('2009-02-13T20:01:30.000-03:30',
        ToTimestampWithZone(1234567890, -3.5))
    self.assertEquals('2009-02-13T20:01:30.456-03:30',
        ToTimestampWithZone(1234567890.4567, -3.5))

  def testFromTimestamp(self):
    # Test values with and without fractional seconds, with and without zones.
    self.assertEquals(0, FromTimestamp('1970-01-01T00:00:00.000Z'))
    self.assertEquals(0, FromTimestamp('1970-01-01T00:00:00Z'))
    self.assertEquals(0, FromTimestamp('1970-01-01T00:00:00-00:00'))
    self.assertEquals(0, FromTimestamp('1970-01-01T00:00:00+00:00'))

    self.assertEquals(1234567890, FromTimestamp('2009-02-13T23:31:30.000Z'))
    self.assertEquals(1234567890, FromTimestamp('2009-02-13T23:31:30Z'))
    self.assertEquals(1234567860, FromTimestamp('2009-02-13T23:31Z'))
    self.assertEquals(1234567890, FromTimestamp('2009-02-13T16:31:30-07:00'))
    self.assertEquals(1234567890, FromTimestamp('2009-02-13T16:31:30-07'))
    self.assertEquals(1234567890, FromTimestamp('2009-02-13T16:31:30-7'))
    self.assertEquals(1234567860, FromTimestamp('2009-02-13T16:31-7'))

    # Test a varying number of decimal places.
    self.assertEquals(0, FromTimestamp('1970-01-01T00:00:00.0001Z'))
    self.assertEquals(0.001, FromTimestamp('1970-01-01T00:00:00.001Z'))
    self.assertEquals(0.01, FromTimestamp('1970-01-01T00:00:00.01Z'))
    self.assertEquals(0.1, FromTimestamp('1970-01-01T00:00:00.1Z'))

    # Test a value known to have floating-point inconsistencies.
    # 32 + 0.001 == 32.000999999999998 != 32001 * 0.001.
    self.assertEquals(32, FromTimestamp('1970-01-01T00:00:32.000999999999998Z'))
    self.assertEquals(32.001, FromTimestamp('1970-01-01T00:00:32.001Z'))

    try:
      FromTimestamp('2009-01-02T03:04:05')  # time zone missing
      self.fail('expected ValueError for missing time zone')
    except ValueError:
      pass  # expected

  def testRoundtrips(self):
    # Test a large set of values for round-trip integrity.
    unix_time = 9e8
    while unix_time < 13e8:
      unix_time += 73624.82013
      trunc_time = int(unix_time * 1000) * 0.001
      self.assertEquals(trunc_time, FromTimestamp(ToTimestamp(unix_time)))
      for zone_offset in [0, -12, -5.5, 3.25, 8.75, 14]:
        self.assertEquals(trunc_time,
            FromTimestamp(ToTimestampWithZone(unix_time, zone_offset)))

if __name__ == '__main__':
  unittest.main()
