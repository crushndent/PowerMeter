#!/usr/bin/python2.4
# Copyright 2009 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Retrieves events from a Google PowerMeter entity.

Specify the kind of event you want to retrieve with --kind=instMeasurement or
--kind=durMeasurement.  The default is instMeasurement.

Specify the time range you want to retrieve either by giving --min and --max,
or --min and --length, or --length and --max.  If you specify only --min
or only --length, then --max defaults to the current time.

The results are shown in UTC unless you specify a time zone offset with --zone.

Here are a few examples:

  - Get the last 24 hours of instantaneous measurements.  "--min=-1d" sets
    the minimum time to 1 standard day ago; the maximum time defaults to now.

    ./get_events.py $TOKEN $VARIABLE --min=-1d

  - Get durational measurements for the last hour of May 10, 2008, UTC.
    "--max" sets the maximum time to the end of that day; "--length=1h"
    sets the length of the time range to 1 hour.

    ./get_events.py $TOKEN $VARIABLE --kind=durMeasurement \\
        --max=2008-05-11T00:00:00Z --length=1h

  - Get the last 5 instantaneous measurements on July 1, 2008, Central
    Daylight Time, and show the results in Central Daylight Time.
    "-f" is shorthand for "--min" and "-l" is shorthand for "--length".

    ./get_events.py $TOKEN $VARIABLE -f 2008-07-01T00:00-5 -l 1d -z -5

In the above examples, $TOKEN is an AuthSub token, such as:
    TOKEN="Cj0Pb5WiVh2TstWrxS"

$VARIABLE is the entity path of a variable, such as:
    VARIABLE="/user/12345678901234567890/12345678901234567890/variable/foo.c1"

All requests require an AuthSub session token that is authorized to read
the specified entity.
"""

from optparse import OptionParser
import os
import re
import socket
import sys
import time

import google_meter
import rfc3339
import units

def parse_period(period):
  """
  Parse a string representing a period of time to yield a number of seconds.
  'period' should be a string containing a plain floating-point number of
  seconds, or a floating-point number followed by "d" for days, "h" for hours,
  "m" for minutes, or "s" for seconds.
  """
  period = period.strip()
  units = {'d': 86400, 'h': 3600, 'm': 60, 's': 1}
  if period[-1:].lower() in units:
    return float(period[:-1].strip()) * units[period[-1].lower()]
  return float(period)


if __name__ == '__main__':
  # Set up the command-line option parser.
  op = OptionParser('%prog <token> <variable>\n\n' + __doc__ + '''
arguments:
  <token>               AuthSub token for GData requests (required)
  <subject>              entity path of a PowerMeter entity (required)''')
  op.add_option('', '--service', metavar='<URI>',
                help='URI prefix of the GData service to contact '
                     '(default: https://www.google.com/powermeter/feeds)')
  op.add_option('-f', '--min', metavar='<time or period>',
                help='earliest time of the range to fetch, either as an RFC '
                     '3339 timestamp or a period relative to now, specified as '
                     'a positive or negative number of days followed by "d", '
                     'a number of hours followed by "h", '
                     'a number of minutes followed by "m", '
                     'or a number of seconds followed by "s"')
  op.add_option('-t', '--max', metavar='<time or period>',
                help='latest time of the range to fetch, either as an RFC '
                     '3339 timestamp or a period relative to now, specified as '
                     'a positive or negative number of days followed by "d", '
                     'a number of hours followed by "h", '
                     'a number of minutes followed by "m", '
                     'or a number of seconds followed by "s"')
  op.add_option('-l', '--length', metavar='<period>',
                help='length of the time range to fetch, specified as '
                     'a number of days followed by "d", '
                     'a number of hours followed by "h", '
                     'a number of minutes followed by "m", '
                     'or a number of seconds followed by "s"')
  op.add_option('-k', '--kind', metavar='<kind>',
                help='kind of event: instMeasurement or durMeasurement '
                     '(default: instMeasurement)')
  op.add_option('-z', '--zone', metavar='<hours>', type='float',
                help='time zone offset for display, in hours east of UTC')
  op.add_option('-v', '--verbose',
                action='store_const', const=2, dest='log_level',
                help='display HTTP requests and replies')
  op.set_defaults(service='https://www.google.com/powermeter/feeds',
                  log_level=1, kind='instMeasurement')

  # Parse and validate the command-line options.
  options, args = op.parse_args()
  if len(args) != 2:
    op.exit(1, op.format_help())
  token, subject = args

  min_time = max_time = None

  if not (options.min or options.length):
    op.error('need --min or --length to determine a time range')
  if not (options.min and options.length):
    max_time = time.time()

  if options.min:
    try:
      min_time = time.time() + parse_period(options.min)
    except ValueError:
      min_time = rfc3339.FromTimestamp(options.min)
  if options.max:
    try:
      max_time = time.time() + parse_period(options.max)
    except ValueError:
      max_time = rfc3339.FromTimestamp(options.max)

  if min_time is None:
    min_time = max_time - parse_period(options.length)
  if max_time is None:
    max_time = min_time + parse_period(options.length)

  # Set up access to the GData service.
  log = google_meter.Log(options.log_level)
  service = google_meter.Service(token, options.service, log=log)

  # Fetch the events.
  if options.zone:
    print >>sys.stderr, 'min time: %s\nmax time: %s' % (
        rfc3339.ToTimestampWithZone(min_time, options.zone),
        rfc3339.ToTimestampWithZone(max_time, options.zone))
  else:
    print >>sys.stderr, 'min time: %s (UTC)\nmax time: %s (UTC)' % (
        rfc3339.ToTimestamp(min_time), rfc3339.ToTimestamp(max_time))

  events = service.GetEvents(subject, options.kind, min_time, max_time)
  print >>sys.stderr, '%s events found: %s' % (options.kind, len(events))
  if len(events) == 1000:
    print >>sys.stderr, '(note: at most 1000 events can be fetched at once)'
  print >>sys.stderr

  for event in reversed(events):  # show in forward chronological order
    if options.zone:
      if hasattr(event, 'occur_time'):  # instantaneous event
        timestamp = rfc3339.ToTimestampWithZone(event.occur_time, options.zone)
      else:
        timestamp = '%s to %s' % (
            rfc3339.ToTimestampWithZone(event.start_time, options.zone),
            rfc3339.ToTimestampWithZone(event.end_time, options.zone))
      description = str(event).split(': ', 1)[1]
      print '%s: %s' % (timestamp, description)
    else:
      print str(event)
