#!/usr/bin/python2.4
# Copyright 2008 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Tests for the google_meter module."""

import socket
import StringIO
import time
import unittest

import google_meter
import units

USER_ID = '01234567890123456789'
PROVIDER_DOMAIN = 'exampleutility.com'
PROVIDER_PATH = '/provider/exampleutility.com'
# NOTE: Message streams are only available to utility providers at this time.
MESSAGE_STREAM_PATH = PROVIDER_PATH + '/messageStream/default'
VARIABLE_ID = 'v1'
VARIABLE_PATH = '/user/01234567890123456789/exampleutility.com/variable/v1'
VARIABLE_URI = 'https://www.google.com/powermeter/feeds' + VARIABLE_PATH
TOKEN = 'abcdefg'


class ModuleTest(unittest.TestCase):
  def setUp(self):
    self.entity = google_meter.Variable(
        USER_ID, PROVIDER_DOMAIN, VARIABLE_ID,
        'name', 'text', 'location',
        'electricity_consumption', 'kW h', True, False)

  def testHtmlEscape(self):
    self.assertEquals('abc', google_meter.HtmlEscape('abc'))
    self.assertEquals('a&lt;c', google_meter.HtmlEscape('a<c'))
    self.assertEquals('&lt;x>', google_meter.HtmlEscape('<x>'))
    self.assertEquals(
        '&lt;&amp;&quot;>&quot;x', google_meter.HtmlEscape('<&">"x'))

  def testIncludeIfTrue(self):
    self.assertEquals('', google_meter.IncludeIfTrue(0, 'abc'))
    self.assertEquals('abc', google_meter.IncludeIfTrue(1, 'abc'))
    self.assertEquals('', google_meter.IncludeIfTrue(False, 'abc'))
    self.assertEquals('abc', google_meter.IncludeIfTrue(True, 'abc'))

  def testGetEntityPath(self):
    self.assertEquals(VARIABLE_PATH, google_meter.GetEntityPath(self.entity))
    self.assertEquals(
        VARIABLE_PATH, google_meter.GetEntityPath(self.entity.path))

  def testGetAtomId(self):
    self.assertEquals(VARIABLE_URI, google_meter.GetAtomId(self.entity))
    self.assertEquals(VARIABLE_URI, google_meter.GetAtomId(self.entity.path))


class LogTest(unittest.TestCase):
  def setUp(self):
    self.buffer = StringIO.StringIO()

  def testDefaultLevel(self):
    log = google_meter.Log(outfile=self.buffer)
    log.Log(0, 'zero')
    log.Log(1, 'one')
    log.Log(2, 'two')
    log.Log(3, 'three')
    log.Log(4, 'four')
    log.Log(5, 'five')

    # The default level of detail should be 1.
    self.assertEquals('zero\none\n', self.buffer.getvalue())

  def testCustomLevel(self):
    log = google_meter.Log(3, self.buffer)
    log.Log(0, 'zero')
    log.Log(1, 'one')
    log.Log(2, 'two')
    log.Log(3, 'three')
    log.Log(4, 'four')
    log.Log(5, 'five')

    self.assertEquals('zero\none\ntwo\nthree\n', self.buffer.getvalue())


class InstMeasurementTest(unittest.TestCase):
  def setUp(self):
    self.event = google_meter.InstMeasurement(
        VARIABLE_PATH, 1240951617, 456 * units.KILOWATT_HOUR,
        0.1, 0.1 * units.KILOWATT_HOUR, True)

  def testStr(self):
    self.assertEquals(
        '2009-04-28T20:46:57.000Z: 456 kW h (initial)', str(self.event))

  def testRepr(self):
    self.assertEquals(
        'InstMeasurement(' +
        "'/user/01234567890123456789/exampleutility.com/variable/v1', " +
        '1240951617, <Quantity: 456 kW h>, ' +
        '0.1, <Quantity: 0.1 kW h>, True)',
        repr(self.event))

  def testEq(self):
    self.assertEquals(True, self.event == google_meter.InstMeasurement(
        VARIABLE_PATH, 1240951617, 456 * units.KILOWATT_HOUR,
        0.1, 0.1 * units.KILOWATT_HOUR, True))
    self.assertEquals(False, self.event == google_meter.InstMeasurement(
        VARIABLE_PATH + 'x', 1240951617, 456 * units.KILOWATT_HOUR,
        0.1, 0.1 * units.KILOWATT_HOUR, True))
    self.assertEquals(False, self.event == google_meter.InstMeasurement(
        VARIABLE_PATH, 1240951618, 456 * units.KILOWATT_HOUR,
        0.1, 0.1 * units.KILOWATT_HOUR, True))
    self.assertEquals(False, self.event == google_meter.InstMeasurement(
        VARIABLE_PATH, 1240951617, 457 * units.KILOWATT_HOUR,
        0.1, 0.1 * units.KILOWATT_HOUR, True))
    self.assertEquals(False, self.event == google_meter.InstMeasurement(
        VARIABLE_PATH, 1240951617, 456 * units.KILOWATT_HOUR,
        0.2, 0.1 * units.KILOWATT_HOUR, True))
    self.assertEquals(False, self.event == google_meter.InstMeasurement(
        VARIABLE_PATH, 1240951617, 456 * units.KILOWATT_HOUR,
        0.1, 0.2 * units.KILOWATT_HOUR, True))

  def testToXml(self):
    self.assertEquals('''
<entry xmlns="http://www.w3.org/2005/Atom" xmlns:meter="http://schemas.google.com/meter/2008">
  <id>https://www.google.com/powermeter/feeds/user/01234567890123456789/exampleutility.com/variable/v1/instMeasurement/2009-04-28T20_46_57.000Z</id>
  <category scheme="http://schemas.google.com/g/2005#kind"
            term="http://schemas.google.com/meter/2008#instMeasurement"/>
  <meter:subject>https://www.google.com/powermeter/feeds/user/01234567890123456789/exampleutility.com/variable/v1</meter:subject>
  <meter:occurTime meter:uncertainty="0.100000">2009-04-28T20:46:57.000Z</meter:occurTime>
  <meter:quantity meter:uncertainty="0.100000" meter:unit="kW h">
    456.000000
  </meter:quantity>
  <meter:initial/>
</entry>
''', self.event.ToXml())

  def testFromXml(self):
    self.assertEquals(
        [self.event], google_meter.ParseEntries(self.event.ToXml()))


class DurMeasurementTest(unittest.TestCase):
  def setUp(self):
    self.event = google_meter.DurMeasurement(
        VARIABLE_PATH, 1240951617, 1240951677, 13 * units.KILOWATT_HOUR,
        0.1, 0.1, 0.1 * units.KILOWATT_HOUR)

  def testStr(self):
    self.assertEquals(
        '2009-04-28T20:46:57.000Z to 2009-04-28T20:47:57.000Z: 13 kW h',
        str(self.event))

  def testRepr(self):
    self.assertEquals(
        'DurMeasurement(' +
        "'/user/01234567890123456789/exampleutility.com/variable/v1', " +
        '1240951617, 1240951677, <Quantity: 13 kW h>, ' +
        '0.1, 0.1, <Quantity: 0.1 kW h>)',
        repr(self.event))

  def testEq(self):
    self.assertEquals(True, self.event == google_meter.DurMeasurement(
        VARIABLE_PATH, 1240951617, 1240951677, 13 * units.KILOWATT_HOUR,
        0.1, 0.1, 0.1 * units.KILOWATT_HOUR))
    self.assertEquals(False, self.event == google_meter.DurMeasurement(
        VARIABLE_PATH + 'x', 1240951617, 1240951677, 13 * units.KILOWATT_HOUR,
        0.1, 0.1, 0.1 * units.KILOWATT_HOUR))
    self.assertEquals(False, self.event == google_meter.DurMeasurement(
        VARIABLE_PATH, 1240951618, 1240951677, 13 * units.KILOWATT_HOUR,
        0.1, 0.1, 0.1 * units.KILOWATT_HOUR))
    self.assertEquals(False, self.event == google_meter.DurMeasurement(
        VARIABLE_PATH, 1240951617, 1240951678, 13 * units.KILOWATT_HOUR,
        0.1, 0.1, 0.1 * units.KILOWATT_HOUR))
    self.assertEquals(False, self.event == google_meter.DurMeasurement(
        VARIABLE_PATH, 1240951617, 1240951677, 14 * units.KILOWATT_HOUR,
        0.1, 0.1, 0.1 * units.KILOWATT_HOUR))
    self.assertEquals(False, self.event == google_meter.DurMeasurement(
        VARIABLE_PATH, 1240951617, 1240951677, 13 * units.KILOWATT_HOUR,
        0.2, 0.1, 0.1 * units.KILOWATT_HOUR))
    self.assertEquals(False, self.event == google_meter.DurMeasurement(
        VARIABLE_PATH, 1240951617, 1240951677, 13 * units.KILOWATT_HOUR,
        0.1, 0.2, 0.1 * units.KILOWATT_HOUR))
    self.assertEquals(False, self.event == google_meter.DurMeasurement(
        VARIABLE_PATH, 1240951617, 1240951677, 13 * units.KILOWATT_HOUR,
        0.1, 0.1, 0.2 * units.KILOWATT_HOUR))

  def testToXml(self):
    self.assertEquals('''
<entry xmlns="http://www.w3.org/2005/Atom" xmlns:meter="http://schemas.google.com/meter/2008">
  <id>https://www.google.com/powermeter/feeds/user/01234567890123456789/exampleutility.com/variable/v1/durMeasurement/2009-04-28T20_46_57.000Z</id>
  <category scheme="http://schemas.google.com/g/2005#kind"
            term="http://schemas.google.com/meter/2008#durMeasurement"/>
  <meter:subject>https://www.google.com/powermeter/feeds/user/01234567890123456789/exampleutility.com/variable/v1</meter:subject>
  <meter:startTime meter:uncertainty="0.100000">2009-04-28T20:46:57.000Z</meter:startTime>
  <meter:endTime meter:uncertainty="0.100000">2009-04-28T20:47:57.000Z</meter:endTime>
  <meter:quantity meter:uncertainty="0.100000" meter:unit="kW h">
    13.000000
  </meter:quantity>
</entry>
''', self.event.ToXml())

  def testFromXml(self):
    self.assertEquals(
        [self.event], google_meter.ParseEntries(self.event.ToXml()))


class DurMessageTest(unittest.TestCase):
  # NOTE: DurMessages are only available to utility providers at this time.
  def setUp(self):
    self.event = google_meter.DurMessage(
        MESSAGE_STREAM_PATH, 1234567890, 1234567900,
        'Title', 'Content', 'http://exampleutility.com/', 0)

  def testStr(self):
    self.assertEquals(
        '2009-02-13T23:31:30.000Z to 2009-02-13T23:31:40.000Z: ' +
        "'Content' (link: 'http://exampleutility.com/'), priority: 0",
        str(self.event))

  def testRepr(self):
    self.assertEquals(
        'DurMessage(' +
        "'/provider/exampleutility.com/messageStream/default', " +
        '1234567890, 1234567900, ' +
        "'Title', 'Content', 'http://exampleutility.com/', 0)",
        repr(self.event))

  def testEq(self):
    self.assertEquals(True, self.event == google_meter.DurMessage(
        MESSAGE_STREAM_PATH, 1234567890, 1234567900,
        'Title', 'Content', 'http://exampleutility.com/', 0))
    self.assertEquals(False, self.event == google_meter.DurMessage(
        MESSAGE_STREAM_PATH, 1234567890, 1234567900,
        'Title', 'Content', 'http://exampleutility.com/', 1))
    self.assertEquals(False, self.event == google_meter.DurMessage(
        MESSAGE_STREAM_PATH, 1234567890, 1234567900,
        'Title', 'Conzent', 'http://exampleutility.com/', 0))

  def testToXml(self):
    self.assertEquals('''
<entry xmlns="http://www.w3.org/2005/Atom" xmlns:meter="http://schemas.google.com/meter/2008">
  <id>https://www.google.com/powermeter/feeds/provider/exampleutility.com/messageStream/default/durMessage/2009-02-13T23_31_30.000Z</id>
  <category scheme="http://schemas.google.com/g/2005#kind"
            term="http://schemas.google.com/meter/2008#durMessage"/>
  <meter:subject>https://www.google.com/powermeter/feeds/provider/exampleutility.com/messageStream/default</meter:subject>
  <meter:startTime meter:uncertainty="0">2009-02-13T23:31:30.000Z</meter:startTime>
  <meter:endTime meter:uncertainty="0">2009-02-13T23:31:40.000Z</meter:endTime>
  <priority>0</priority>
  <title type="text">Title</title>
  <content type="text">Content</content>
  <link rel="related" href="http://exampleutility.com/"/>
</entry>
''', self.event.ToXml())

  def testFromXml(self):
    self.assertEquals(
        [self.event], google_meter.ParseEntries(self.event.ToXml()))


class VariableTest(unittest.TestCase):
  def setUp(self):
    self.variable = google_meter.Variable(
        USER_ID, PROVIDER_DOMAIN, VARIABLE_ID,
        'name', 'text', 'location',
        'electricity_consumption', 'kW h', True, False)

  def testRepr(self):
    self.assertEquals(
        '<Variable at '
        '/user/01234567890123456789/exampleutility.com/variable/v1>',
        repr(self.variable))

  def testEq(self):
    self.assertEquals(True, self.variable == google_meter.Variable(
        USER_ID, PROVIDER_DOMAIN, VARIABLE_ID,
        'name', 'text', 'location',
        'electricity_consumption', 'kW h', True, False))
    self.assertEquals(False, self.variable == google_meter.Variable(
        USER_ID, PROVIDER_DOMAIN + 'x', VARIABLE_ID,
        'name', 'text', 'location',
        'electricity_consumption', 'kW h', True, False))

  def testToXml(self):
    self.assertEquals('''
<entry xmlns="http://www.w3.org/2005/Atom" xmlns:meter="http://schemas.google.com/meter/2008">
  <id>https://www.google.com/powermeter/feeds/user/01234567890123456789/exampleutility.com/variable/v1</id>
  <meter:variableId>v1</meter:variableId>
  <title>name</title>
  <content type="text">text</content>
  <meter:location>location</meter:location>
  <meter:type>electricity_consumption</meter:type>
  <meter:unit>kW h</meter:unit>
  <meter:cumulative/>
</entry>
''', self.variable.ToXml())

  def testFromXml(self):
    self.assertEquals(
        [self.variable], google_meter.ParseEntries(self.variable.ToXml()))


class MessageStream(unittest.TestCase):
# NOTE: Message streams are only available to utility providers at this time.
  def setUp(self):
    self.stream = google_meter.MessageStream(
        PROVIDER_DOMAIN, 'stream1', 'name', 'text')

  def testRepr(self):
    self.assertEquals(
        '<MessageStream at ' +
        '/provider/exampleutility.com/messageStream/stream1>',
        repr(self.stream))

  def testEq(self):
    self.assertEquals(True, self.stream == google_meter.MessageStream(
        PROVIDER_DOMAIN, 'stream1', 'name', 'text'))
    self.assertEquals(False, self.stream == google_meter.MessageStream(
        PROVIDER_DOMAIN, 'swream1', 'name', 'text'))

  def testToXml(self):
    self.assertEquals('''
<entry xmlns="http://www.w3.org/2005/Atom" xmlns:meter="http://schemas.google.com/meter/2008">
  <id>https://www.google.com/powermeter/feeds/provider/exampleutility.com/messageStream/stream1</id>
  <meter:messageStreamId>stream1</meter:messageStreamId>
  <title>name</title>
  <content type="text">text</content>
</entry>
''', self.stream.ToXml())

  def testFromXml(self):
    self.assertEquals(
        [self.stream], google_meter.ParseEntries(self.stream.ToXml()))


class FakeSocket(object):
  def __init__(self, status, error=None):
    """Use the 'status' argument to set the HTTP status code of the reply."""
    self.status = status
    self.reply = ''
    self.error = error

  def __call__(self):
    return self

  def socket(self):
    return self

  def connect(self, (host, port)):
    self.host = host
    self.port = port

  def ssl(self, fake_socket):
    fake_socket.secure = True
    return fake_socket

  def makefile(self):
    self.secure = False
    return self

  def write(self, request):
    self.request = request
    self.reply = 'HTTP/1.0 %s Whatever\n' % self.status

  def read(self):
    if self.error:
      # Simulate a socket error.
      raise self.error
    result = self.reply
    if not self.reply and self.secure:
      # This is what an SSL-enabled socket does at end-of-file.
      raise socket.error(socket.SSL_ERROR_EOF)
    self.reply = ''
    return result

  def flush(self):
    pass

  def close(self):
    pass


class AbstractSocketTest(unittest.TestCase):
  def setUp(self):
    """Patch the socket module to make FakeSockets instead of real ones."""
    self.socket = FakeSocket(200)
    self.original_socket = socket.socket
    self.original_ssl = socket.ssl
    socket.socket = self.socket
    socket.ssl = self.socket.ssl
    self.service = google_meter.Service(TOKEN, log=google_meter.Log(0))

  def tearDown(self):
    """Restore the socket module."""
    socket.socket = self.original_socket
    socket.ssl = self.original_ssl


class ServiceTest(AbstractSocketTest):
  def testConstructor(self):
    service = google_meter.Service(TOKEN)
    self.assertEquals('www.google.com', service.host)
    self.assertEquals(443, service.port)

    service = google_meter.Service(TOKEN, 'http://foo.com/bar')
    self.assertEquals('foo.com', service.host)
    self.assertEquals(80, service.port)

    service = google_meter.Service(TOKEN, 'https://foo.com:1234/bar')
    self.assertEquals('foo.com', service.host)
    self.assertEquals(1234, service.port)

  def testRepr(self):
    self.assertEquals(
        '<Google Meter service at www.google.com:443>', repr(self.service))

  def testStr(self):
    self.assertEquals('www.google.com:443', str(self.service))

  def testSslError(self):
    self.socket.error = socket.error(socket.SSL_ERROR_SSL)
    try:
      self.service.Post('/foo', 'bar')
      self.fail('SSL error was incorrectly suppressed')
    except socket.error, e:
      self.assertEquals(self.socket.error, e)  # expected

  def testHttpError(self):
    self.socket.status = 404
    try:
      self.service.Post('/foo', 'bar')
      self.fail('HTTP error was incorrectly suppressed')
    except IOError, e:
      self.assertEquals('404', e.args[0].split()[1])  # expected

  def testPost(self):
    self.service.Post('/foo', 'bar')
    self.assertEquals(True, self.socket.secure)
    self.assertEquals('''
POST /powermeter/feeds/foo HTTP/1.0
Host: www.google.com
Authorization: AuthSub token="abcdefg"
Content-Type: application/atom+xml
Content-Length: 3

bar
'''.strip(), self.socket.request.strip())

  def testNonSslPost(self):
    self.service = google_meter.Service(TOKEN, 'http://foo.com/bar')
    self.service.Post('/foo', 'bar')
    self.assertEquals(False, self.socket.secure)
    self.assertEquals('''
POST /bar/foo HTTP/1.0
Host: foo.com
Authorization: AuthSub token="abcdefg"
Content-Type: application/atom+xml
Content-Length: 3

bar
'''.strip(), self.socket.request.strip())

  def testPostXml(self):
    self.service.PostXml('/foo', '<bar/>')
    self.assertEquals('''
POST /powermeter/feeds/foo HTTP/1.0
Host: www.google.com
Authorization: AuthSub token="abcdefg"
Content-Type: application/atom+xml
Content-Length: 28

<?xml version="1.0"?>
<bar/>
'''.strip(), self.socket.request.strip())

  def testPostEntity(self):
    variable = google_meter.Variable(
        USER_ID, PROVIDER_DOMAIN, VARIABLE_ID,
        'name', 'text', 'location',
        'electricity_consumption', 'kW h', True, False)
    self.service.PostEntity(variable)
    self.assertEquals('''
POST /powermeter/feeds/user/01234567890123456789/exampleutility.com/variable HTTP/1.0
Host: www.google.com
Authorization: AuthSub token="abcdefg"
Content-Type: application/atom+xml
Content-Length: 485

<?xml version="1.0"?>
<entry xmlns="http://www.w3.org/2005/Atom" xmlns:meter="http://schemas.google.com/meter/2008">
  <id>https://www.google.com/powermeter/feeds/user/01234567890123456789/exampleutility.com/variable/v1</id>
  <meter:variableId>v1</meter:variableId>
  <title>name</title>
  <content type="text">text</content>
  <meter:location>location</meter:location>
  <meter:type>electricity_consumption</meter:type>
  <meter:unit>kW h</meter:unit>
  <meter:cumulative/>
</entry>
'''.strip(), self.socket.request.strip())

  def testPostEvent(self):
    event = google_meter.InstMeasurement(
        VARIABLE_PATH, 1240951617, 456 * units.KILOWATT_HOUR,
        0.1, 0.1 * units.KILOWATT_HOUR, True)
    self.service.PostEvent(event)
    self.assertEquals('''
POST /powermeter/feeds/user/01234567890123456789/exampleutility.com/variable/v1/instMeasurement HTTP/1.0
Host: www.google.com
Authorization: AuthSub token="abcdefg"
Content-Type: application/atom+xml
Content-Length: 749

<?xml version="1.0"?>
<entry xmlns="http://www.w3.org/2005/Atom" xmlns:meter="http://schemas.google.com/meter/2008">
  <id>https://www.google.com/powermeter/feeds/user/01234567890123456789/exampleutility.com/variable/v1/instMeasurement/2009-04-28T20_46_57.000Z</id>
  <category scheme="http://schemas.google.com/g/2005#kind"
            term="http://schemas.google.com/meter/2008#instMeasurement"/>
  <meter:subject>https://www.google.com/powermeter/feeds/user/01234567890123456789/exampleutility.com/variable/v1</meter:subject>
  <meter:occurTime meter:uncertainty="0.100000">2009-04-28T20:46:57.000Z</meter:occurTime>
  <meter:quantity meter:uncertainty="0.100000" meter:unit="kW h">
    456.000000
  </meter:quantity>
  <meter:initial/>
</entry>
'''.strip(), self.socket.request.strip())

  def testBatchPostEvents(self):
    events = [
        google_meter.InstMeasurement(
            VARIABLE_PATH, 1240951617, 456 * units.KILOWATT_HOUR,
            0.1, 0.1 * units.KILOWATT_HOUR, True),
        google_meter.InstMeasurement(
            VARIABLE_PATH, 1240951700, 488 * units.KILOWATT_HOUR,
            0.1, 0.1 * units.KILOWATT_HOUR, False),
        google_meter.InstMeasurement(
            VARIABLE_PATH, 1240951780, 500 * units.KILOWATT_HOUR,
            0.1, 0.1 * units.KILOWATT_HOUR, False)
    ]
    self.service.BatchPostEvents(events)
    self.assertEquals('''
POST /powermeter/feeds/event HTTP/1.0
Host: www.google.com
Authorization: AuthSub token="abcdefg"
Content-Type: application/atom+xml
Content-Length: 2268

<?xml version="1.0"?>
<feed xmlns="http://www.w3.org/2005/Atom" xmlns:meter="http://schemas.google.com/meter/2008">
<entry xmlns="http://www.w3.org/2005/Atom" xmlns:meter="http://schemas.google.com/meter/2008">
  <id>https://www.google.com/powermeter/feeds/user/01234567890123456789/exampleutility.com/variable/v1/instMeasurement/2009-04-28T20_46_57.000Z</id>
  <category scheme="http://schemas.google.com/g/2005#kind"
            term="http://schemas.google.com/meter/2008#instMeasurement"/>
  <meter:subject>https://www.google.com/powermeter/feeds/user/01234567890123456789/exampleutility.com/variable/v1</meter:subject>
  <meter:occurTime meter:uncertainty="0.100000">2009-04-28T20:46:57.000Z</meter:occurTime>
  <meter:quantity meter:uncertainty="0.100000" meter:unit="kW h">
    456.000000
  </meter:quantity>
  <meter:initial/>
</entry>

<entry xmlns="http://www.w3.org/2005/Atom" xmlns:meter="http://schemas.google.com/meter/2008">
  <id>https://www.google.com/powermeter/feeds/user/01234567890123456789/exampleutility.com/variable/v1/instMeasurement/2009-04-28T20_48_20.000Z</id>
  <category scheme="http://schemas.google.com/g/2005#kind"
            term="http://schemas.google.com/meter/2008#instMeasurement"/>
  <meter:subject>https://www.google.com/powermeter/feeds/user/01234567890123456789/exampleutility.com/variable/v1</meter:subject>
  <meter:occurTime meter:uncertainty="0.100000">2009-04-28T20:48:20.000Z</meter:occurTime>
  <meter:quantity meter:uncertainty="0.100000" meter:unit="kW h">
    488.000000
  </meter:quantity>
</entry>

<entry xmlns="http://www.w3.org/2005/Atom" xmlns:meter="http://schemas.google.com/meter/2008">
  <id>https://www.google.com/powermeter/feeds/user/01234567890123456789/exampleutility.com/variable/v1/instMeasurement/2009-04-28T20_49_40.000Z</id>
  <category scheme="http://schemas.google.com/g/2005#kind"
            term="http://schemas.google.com/meter/2008#instMeasurement"/>
  <meter:subject>https://www.google.com/powermeter/feeds/user/01234567890123456789/exampleutility.com/variable/v1</meter:subject>
  <meter:occurTime meter:uncertainty="0.100000">2009-04-28T20:49:40.000Z</meter:occurTime>
  <meter:quantity meter:uncertainty="0.100000" meter:unit="kW h">
    500.000000
  </meter:quantity>
</entry>
</feed>
'''.strip(), self.socket.request.strip())


class FakeService(object):
  def __init__(self):
    self.events = []

  def PostEvent(self, event):
    self.events.append(event)


class FakeTime(object):
  def __init__(self, value):
    self.value = value

  def __call__(self):
    return self.value


class MeterTest(unittest.TestCase):
  def setUp(self):
    self.service = FakeService()
    self.time = FakeTime(1234567890)
    self.original_time = time.time
    time.time = self.time
    self.meter = google_meter.Meter(
        self.service, VARIABLE_PATH, 0.1 * units.KILOWATT_HOUR, 0.5)

  def tearDown(self):
    time.time = self.original_time

  def testPostRegisterReading(self):
    # Test a couple of register readings.
    self.meter.PostRegisterReading(
        5 * units.KILOWATT_HOUR, read_time=1234567890)
    self.meter.PostRegisterReading(
        6 * units.KILOWATT_HOUR, read_time=1234567900)
    # Test the reset feature.
    self.meter.Reset()
    # Add a couple more register readings.
    self.meter.PostRegisterReading(
        7 * units.KILOWATT_HOUR, read_time=1234567910)
    self.meter.PostRegisterReading(
        8 * units.KILOWATT_HOUR, read_time=1234567920)

    self.assertEquals([
        google_meter.InstMeasurement(
            VARIABLE_PATH, 1234567890, 5 * units.KILOWATT_HOUR,
            0.5, 0.1 * units.KILOWATT_HOUR, True),
        google_meter.InstMeasurement(
            VARIABLE_PATH, 1234567900, 6 * units.KILOWATT_HOUR,
            0.5, 0.1 * units.KILOWATT_HOUR, False),
        google_meter.InstMeasurement(
            VARIABLE_PATH, 1234567910, 7 * units.KILOWATT_HOUR,
            0.5, 0.1 * units.KILOWATT_HOUR, True),
        google_meter.InstMeasurement(
            VARIABLE_PATH, 1234567920, 8 * units.KILOWATT_HOUR,
            0.5, 0.1 * units.KILOWATT_HOUR, False),
    ], self.service.events)

  def testPostRealtimeRegisterReading(self):
    # Test a register reading with time from the clock.
    self.meter.PostRegisterReading(5 * units.KILOWATT_HOUR)
    self.time.value = 1234567900
    self.meter.PostRegisterReading(6 * units.KILOWATT_HOUR)

    self.assertEquals([
        google_meter.InstMeasurement(
            VARIABLE_PATH, 1234567890, 5 * units.KILOWATT_HOUR,
            0.5, 0.1 * units.KILOWATT_HOUR, True),
        google_meter.InstMeasurement(
            VARIABLE_PATH, 1234567900, 6 * units.KILOWATT_HOUR,
            0.5, 0.1 * units.KILOWATT_HOUR, False),
    ], self.service.events)

  def testPostIntervalReading(self):
    # Test an ordinary interval.
    self.meter.PostIntervalReading(
        5 * units.KILOWATT_HOUR, start_time=1234567890, end_time=1234567900)
    # Test an interval that begins exactly when the previous interval ends.
    self.meter.PostIntervalReading(
        6 * units.KILOWATT_HOUR, start_time=1234567900, end_time=1234567910)
    # Test conversion from watts to kilowatt-hours.
    self.meter.PostIntervalReading(
        100 * units.WATT, start_time=1234567910, end_time=1234567910 + 3600)
    # Test an interval that begins some time after the previous interval ends.
    self.meter.PostIntervalReading(
        7 * units.KILOWATT_HOUR, start_time=1234580000, end_time=1234580010)

    self.assertEquals([
        google_meter.InstMeasurement(
            VARIABLE_PATH, 1234567890, 0 * units.KILOWATT_HOUR,
            0.5, 0.1 * units.KILOWATT_HOUR, True),
        google_meter.InstMeasurement(
            VARIABLE_PATH, 1234567900, 5 * units.KILOWATT_HOUR,
            0.5, 0.1 * units.KILOWATT_HOUR, False),
        google_meter.InstMeasurement(
            VARIABLE_PATH, 1234567910, 11 * units.KILOWATT_HOUR,
            0.5, 0.1 * units.KILOWATT_HOUR, False),
        google_meter.InstMeasurement(
            VARIABLE_PATH, 1234567910 + 3600, 11.1 * units.KILOWATT_HOUR,
            0.5, 0.1 * units.KILOWATT_HOUR, False),
        google_meter.InstMeasurement(
            VARIABLE_PATH, 1234580000, 11.1 * units.KILOWATT_HOUR,
            0.5, 0.1 * units.KILOWATT_HOUR, True),
        google_meter.InstMeasurement(
            VARIABLE_PATH, 1234580010, 18.1 * units.KILOWATT_HOUR,
            0.5, 0.1 * units.KILOWATT_HOUR, False),
    ], self.service.events)

  def testPostIntervalReadingWithoutStartTime(self):
    # Test specifying the first interval with no start time.
    self.meter.PostIntervalReading(
        4 * units.KILOWATT_HOUR, end_time=1234567890)
    # Test allowing the start time to be inferred from the last end_time.
    self.meter.PostIntervalReading(
        5 * units.KILOWATT_HOUR, end_time=1234567900)

    self.assertEquals([
        google_meter.InstMeasurement(
            VARIABLE_PATH, 1234567890, 0 * units.KILOWATT_HOUR,
            0.5, 0.1 * units.KILOWATT_HOUR, True),
        google_meter.InstMeasurement(
            VARIABLE_PATH, 1234567900, 5 * units.KILOWATT_HOUR,
            0.5, 0.1 * units.KILOWATT_HOUR, False),
    ], self.service.events)

  def testPostRealtimeIntervalReading(self):
    # Test an interval reading with time from the clock.
    self.meter.PostIntervalReading(5 * units.KILOWATT_HOUR)
    self.time.value = 1234567900
    self.meter.PostIntervalReading(6 * units.KILOWATT_HOUR)

    self.assertEquals([
        google_meter.InstMeasurement(
            VARIABLE_PATH, 1234567890, 0 * units.KILOWATT_HOUR,
            0.5, 0.1 * units.KILOWATT_HOUR, True),
        google_meter.InstMeasurement(
            VARIABLE_PATH, 1234567900, 6 * units.KILOWATT_HOUR,
            0.5, 0.1 * units.KILOWATT_HOUR, False),
    ], self.service.events)


class BatchAdapterTest(AbstractSocketTest):
  def testBatchAdapter(self):
    adapter = google_meter.BatchAdapter(self.service)
    meter = google_meter.Meter(
        adapter, VARIABLE_PATH, 0.1 * units.KILOWATT_HOUR, 0.5)

    # Test a couple of register readings.
    meter.PostRegisterReading(
        5 * units.KILOWATT_HOUR, read_time=1234567890)
    meter.PostRegisterReading(
        6 * units.KILOWATT_HOUR, read_time=1234567900)
    # Test the reset feature.
    meter.Reset()
    # Add a couple more register readings.
    meter.PostRegisterReading(
        7 * units.KILOWATT_HOUR, read_time=1234567910)
    meter.PostRegisterReading(
        8 * units.KILOWATT_HOUR, read_time=1234567920)

    # Flush the batch post buffer.
    adapter.Flush()

    # Check the posted XML data.
    self.assertEquals('''
POST /powermeter/feeds/event HTTP/1.0
Host: www.google.com
Authorization: AuthSub token="abcdefg"
Content-Type: application/atom+xml
Content-Length: 2988

<?xml version="1.0"?>
<feed xmlns="http://www.w3.org/2005/Atom" xmlns:meter="http://schemas.google.com/meter/2008">
<entry xmlns="http://www.w3.org/2005/Atom" xmlns:meter="http://schemas.google.com/meter/2008">
  <id>https://www.google.com/powermeter/feeds/user/01234567890123456789/exampleutility.com/variable/v1/instMeasurement/2009-02-13T23_31_30.000Z</id>
  <category scheme="http://schemas.google.com/g/2005#kind"
            term="http://schemas.google.com/meter/2008#instMeasurement"/>
  <meter:subject>https://www.google.com/powermeter/feeds/user/01234567890123456789/exampleutility.com/variable/v1</meter:subject>
  <meter:occurTime meter:uncertainty="0.500000">2009-02-13T23:31:30.000Z</meter:occurTime>
  <meter:quantity meter:uncertainty="0.100000" meter:unit="kW h">
    5.000000
  </meter:quantity>
  <meter:initial/>
</entry>

<entry xmlns="http://www.w3.org/2005/Atom" xmlns:meter="http://schemas.google.com/meter/2008">
  <id>https://www.google.com/powermeter/feeds/user/01234567890123456789/exampleutility.com/variable/v1/instMeasurement/2009-02-13T23_31_40.000Z</id>
  <category scheme="http://schemas.google.com/g/2005#kind"
            term="http://schemas.google.com/meter/2008#instMeasurement"/>
  <meter:subject>https://www.google.com/powermeter/feeds/user/01234567890123456789/exampleutility.com/variable/v1</meter:subject>
  <meter:occurTime meter:uncertainty="0.500000">2009-02-13T23:31:40.000Z</meter:occurTime>
  <meter:quantity meter:uncertainty="0.100000" meter:unit="kW h">
    6.000000
  </meter:quantity>
</entry>

<entry xmlns="http://www.w3.org/2005/Atom" xmlns:meter="http://schemas.google.com/meter/2008">
  <id>https://www.google.com/powermeter/feeds/user/01234567890123456789/exampleutility.com/variable/v1/instMeasurement/2009-02-13T23_31_50.000Z</id>
  <category scheme="http://schemas.google.com/g/2005#kind"
            term="http://schemas.google.com/meter/2008#instMeasurement"/>
  <meter:subject>https://www.google.com/powermeter/feeds/user/01234567890123456789/exampleutility.com/variable/v1</meter:subject>
  <meter:occurTime meter:uncertainty="0.500000">2009-02-13T23:31:50.000Z</meter:occurTime>
  <meter:quantity meter:uncertainty="0.100000" meter:unit="kW h">
    7.000000
  </meter:quantity>
  <meter:initial/>
</entry>

<entry xmlns="http://www.w3.org/2005/Atom" xmlns:meter="http://schemas.google.com/meter/2008">
  <id>https://www.google.com/powermeter/feeds/user/01234567890123456789/exampleutility.com/variable/v1/instMeasurement/2009-02-13T23_32_00.000Z</id>
  <category scheme="http://schemas.google.com/g/2005#kind"
            term="http://schemas.google.com/meter/2008#instMeasurement"/>
  <meter:subject>https://www.google.com/powermeter/feeds/user/01234567890123456789/exampleutility.com/variable/v1</meter:subject>
  <meter:occurTime meter:uncertainty="0.500000">2009-02-13T23:32:00.000Z</meter:occurTime>
  <meter:quantity meter:uncertainty="0.100000" meter:unit="kW h">
    8.000000
  </meter:quantity>
</entry>
</feed>
'''.strip(), self.socket.request.strip())


if __name__ == '__main__':
  unittest.main()
