#!/usr/bin/python2.4
# Copyright 2009 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Batch-post XML documents containing measurement events to Google PowerMeter.

NOTE: Batches should contain no more than 1000 entries.  To split up a larger
XML file into batches, use split_batch_data_xml.py.

All requests require an AuthSub session token that is authorized to post the
measurements to their specified variables.
"""

from optparse import OptionParser
import google_meter


if __name__ == '__main__':
  # Set up the command-line option parser.
  op = OptionParser('%prog <token> <filename> ...\n\n' + __doc__ + '''
arguments:
  <token>               AuthSub token for GData requests (required)
  <filename>            one or more files to upload''')
  op.add_option('', '--service', metavar='<URI>',
                help='URI prefix of the GData service to contact '
                     '(default: https://www.google.com/powermeter/feeds)')
  op.add_option('-v', '--verbose',
                action='store_const', const=2, dest='log_level',
                help='display HTTP requests and replies')
  op.set_defaults(service='https://www.google.com/powermeter/feeds',
                  log_level=1)

  # Parse the command-line options.
  options, args = op.parse_args()
  if len(args) < 2:
    op.exit(1, op.format_help())
  token = args[0]
  filenames = args[1:]

  # Set up access to the GData service.
  log = google_meter.Log(options.log_level)
  service = google_meter.Service(token, options.service, log=log)

  for filename in filenames:
    # Read the entire file into a string and post the string.
    xml_string = open(filename, 'r').read()
    service.Post('/event', xml_string)
